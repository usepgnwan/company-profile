"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["resources_js_views_Front_Fron_vue"],{

/***/ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Front/Fron.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Front/Fron.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  name: "Front"
});

/***/ }),

/***/ "./resources/js/views/Front/Fron.vue":
/*!*******************************************!*\
  !*** ./resources/js/views/Front/Fron.vue ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Fron_vue_vue_type_template_id_4e9ccdd0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Fron.vue?vue&type=template&id=4e9ccdd0& */ "./resources/js/views/Front/Fron.vue?vue&type=template&id=4e9ccdd0&");
/* harmony import */ var _Fron_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Fron.vue?vue&type=script&lang=js& */ "./resources/js/views/Front/Fron.vue?vue&type=script&lang=js&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */
;
var component = (0,_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Fron_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Fron_vue_vue_type_template_id_4e9ccdd0___WEBPACK_IMPORTED_MODULE_0__.render,
  _Fron_vue_vue_type_template_id_4e9ccdd0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns,
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/views/Front/Fron.vue"
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (component.exports);

/***/ }),

/***/ "./resources/js/views/Front/Fron.vue?vue&type=script&lang=js&":
/*!********************************************************************!*\
  !*** ./resources/js/views/Front/Fron.vue?vue&type=script&lang=js& ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Fron_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Fron.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js??clonedRuleSet-5[0].rules[0].use[0]!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Front/Fron.vue?vue&type=script&lang=js&");
 /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_babel_loader_lib_index_js_clonedRuleSet_5_0_rules_0_use_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Fron_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/views/Front/Fron.vue?vue&type=template&id=4e9ccdd0&":
/*!**************************************************************************!*\
  !*** ./resources/js/views/Front/Fron.vue?vue&type=template&id=4e9ccdd0& ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Fron_vue_vue_type_template_id_4e9ccdd0___WEBPACK_IMPORTED_MODULE_0__.render),
/* harmony export */   staticRenderFns: () => (/* reexport safe */ _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Fron_vue_vue_type_template_id_4e9ccdd0___WEBPACK_IMPORTED_MODULE_0__.staticRenderFns)
/* harmony export */ });
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Fron_vue_vue_type_template_id_4e9ccdd0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../node_modules/vue-loader/lib/index.js??vue-loader-options!./Fron.vue?vue&type=template&id=4e9ccdd0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Front/Fron.vue?vue&type=template&id=4e9ccdd0&");


/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Front/Fron.vue?vue&type=template&id=4e9ccdd0&":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib/index.js??vue-loader-options!./resources/js/views/Front/Fron.vue?vue&type=template&id=4e9ccdd0& ***!
  \*****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   render: () => (/* binding */ render),
/* harmony export */   staticRenderFns: () => (/* binding */ staticRenderFns)
/* harmony export */ });
var render = function () {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("main", [
    _c(
      "div",
      {
        staticClass: "elementor elementor-806",
        attrs: { "data-elementor-type": "wp-page", "data-elementor-id": "806" },
      },
      [
        _c(
          "section",
          {
            staticClass:
              "elementor-section elementor-top-section elementor-element elementor-element-e4bc5a3 wdp-sticky-section-yes wdp-sticky-section-positon-top elementor-hidden-desktop elementor-hidden-tablet elementor-section-boxed elementor-section-height-default elementor-section-height-default",
            attrs: {
              "data-id": "e4bc5a3",
              "data-element_type": "section",
              "data-settings": '{"background_background":"classic"}',
            },
          },
          [
            _c(
              "div",
              {
                staticClass: "elementor-container elementor-column-gap-default",
              },
              [
                _vm._m(0),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-3fd4fa3 wdp-sticky-section-no",
                    attrs: {
                      "data-id": "3fd4fa3",
                      "data-element_type": "column",
                    },
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-widget-wrap elementor-element-populated",
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-element elementor-element-1c3bc99 elementor-nav-menu__align-center elementor-nav-menu--stretch elementor-nav-menu--dropdown-tablet elementor-nav-menu__text-align-aside elementor-nav-menu--toggle elementor-nav-menu--burger de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-nav-menu",
                            attrs: {
                              "data-id": "1c3bc99",
                              "data-element_type": "widget",
                              "data-settings":
                                '{"submenu_icon":{"value":"<i class=\\"\\"><\\/i>","library":""},"full_width":"stretch","layout":"horizontal","toggle":"burger"}',
                              "data-widget_type": "nav-menu.default",
                            },
                          },
                          [
                            _c(
                              "div",
                              { staticClass: "elementor-widget-container" },
                              [
                                _vm._m(1),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  {
                                    staticClass: "elementor-menu-toggle",
                                    attrs: {
                                      role: "button",
                                      tabindex: "0",
                                      "aria-label": "Menu Toggle",
                                      "aria-expanded": "false",
                                    },
                                  },
                                  [
                                    _c(
                                      "svg",
                                      {
                                        staticClass:
                                          "elementor-menu-toggle__icon--open e-font-icon-svg e-eicon-menu-bar",
                                        attrs: {
                                          "aria-hidden": "true",
                                          role: "presentation",
                                          viewBox: "0 0 1000 1000",
                                          xmlns: "http://www.w3.org/2000/svg",
                                        },
                                      },
                                      [
                                        _c("path", {
                                          attrs: {
                                            d: "M104 333H896C929 333 958 304 958 271S929 208 896 208H104C71 208 42 237 42 271S71 333 104 333ZM104 583H896C929 583 958 554 958 521S929 458 896 458H104C71 458 42 487 42 521S71 583 104 583ZM104 833H896C929 833 958 804 958 771S929 708 896 708H104C71 708 42 737 42 771S71 833 104 833Z",
                                          },
                                        }),
                                      ]
                                    ),
                                    _c(
                                      "svg",
                                      {
                                        staticClass:
                                          "elementor-menu-toggle__icon--close e-font-icon-svg e-eicon-close",
                                        attrs: {
                                          "aria-hidden": "true",
                                          role: "presentation",
                                          viewBox: "0 0 1000 1000",
                                          xmlns: "http://www.w3.org/2000/svg",
                                        },
                                      },
                                      [
                                        _c("path", {
                                          attrs: {
                                            d: "M742 167L500 408 258 167C246 154 233 150 217 150 196 150 179 158 167 167 154 179 150 196 150 212 150 229 154 242 171 254L408 500 167 742C138 771 138 800 167 829 196 858 225 858 254 829L496 587 738 829C750 842 767 846 783 846 800 846 817 842 829 829 842 817 846 804 846 783 846 767 842 750 829 737L588 500 833 258C863 229 863 200 833 171 804 137 775 137 742 167Z",
                                          },
                                        }),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "span",
                                      { staticClass: "elementor-screen-only" },
                                      [_vm._v("Menu")]
                                    ),
                                  ]
                                ),
                                _vm._v(" "),
                                _vm._m(2),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
        _vm._v(" "),
        _vm._m(3),
        _vm._v(" "),
        _c(
          "section",
          {
            staticClass:
              "elementor-section elementor-top-section elementor-element elementor-element-121cb51 wdp-sticky-section-yes wdp-sticky-section-positon-top elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-sticky animated fadeInDown elementor-sticky--active elementor-section--handles-inside",
            staticStyle: {
              position: "fixed",
              width: "100px",
              "margin-top": "0px",
              "margin-bottom": "0px",
              top: "0px",
            },
            attrs: {
              "data-id": "121cb51",
              "data-element_type": "section",
              "data-settings":
                '{"background_background":"classic","sticky":"top","sticky_effects_offset":15,"animation":"fadeInDown","sticky_on":["desktop","tablet","mobile"],"sticky_offset":0}',
            },
          },
          [
            _c(
              "div",
              {
                staticClass: "elementor-container elementor-column-gap-default",
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6ff996d wdp-sticky-section-no",
                    attrs: {
                      "data-id": "6ff996d",
                      "data-element_type": "column",
                    },
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-widget-wrap elementor-element-populated",
                      },
                      [
                        _c(
                          "section",
                          {
                            staticClass:
                              "elementor-section elementor-inner-section elementor-element elementor-element-1769e5b elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                            attrs: {
                              "data-id": "1769e5b",
                              "data-element_type": "section",
                            },
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-container elementor-column-gap-default",
                              },
                              [
                                _vm._m(4),
                                _vm._v(" "),
                                _vm._m(5),
                                _vm._v(" "),
                                _vm._m(6),
                                _vm._v(" "),
                                _vm._m(7),
                                _vm._v(" "),
                                _vm._m(8),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-9890fce wdp-sticky-section-no",
                                    attrs: {
                                      "data-id": "9890fce",
                                      "data-element_type": "column",
                                    },
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-widget-wrap elementor-element-populated",
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-element elementor-element-429c7ea elementor-align-right elementor-widget-tablet__width-initial elementor-widget__width-initial de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-button",
                                            attrs: {
                                              "data-id": "429c7ea",
                                              "data-element_type": "widget",
                                              "data-widget_type":
                                                "button.default",
                                            },
                                          },
                                          [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "elementor-widget-container",
                                              },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "elementor-button-wrapper",
                                                  },
                                                  [
                                                    _c(
                                                      "a",
                                                      {
                                                        staticClass:
                                                          "elementor-button elementor-button-link elementor-size-sm",
                                                        attrs: {
                                                          href: "https://wa.me/6283821877654",
                                                        },
                                                      },
                                                      [
                                                        _c(
                                                          "span",
                                                          {
                                                            staticClass:
                                                              "elementor-button-content-wrapper",
                                                          },
                                                          [
                                                            _c(
                                                              "span",
                                                              {
                                                                staticClass:
                                                                  "elementor-button-icon elementor-align-icon-right",
                                                              },
                                                              [
                                                                _c(
                                                                  "svg",
                                                                  {
                                                                    staticClass:
                                                                      "e-font-icon-svg e-fas-arrow-right",
                                                                    attrs: {
                                                                      "aria-hidden":
                                                                        "true",
                                                                      viewBox:
                                                                        "0 0 448 512",
                                                                      xmlns:
                                                                        "http://www.w3.org/2000/svg",
                                                                    },
                                                                  },
                                                                  [
                                                                    _c("path", {
                                                                      attrs: {
                                                                        d: "M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z",
                                                                      },
                                                                    }),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "span",
                                                              {
                                                                staticClass:
                                                                  "elementor-button-text",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "Gratis\n                                                                konsultasi"
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
        _vm._v(" "),
        _c(
          "section",
          {
            staticClass:
              "elementor-section elementor-top-section elementor-element elementor-element-121cb51 wdp-sticky-section-yes wdp-sticky-section-positon-top elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-invisible elementor-sticky elementor-sticky__spacer",
            staticStyle: {
              visibility: "hidden",
              transition: "none 0s ease 0s",
              animation: "0s ease 0s 1 normal none running none",
            },
            attrs: {
              "data-id": "121cb51",
              "data-element_type": "section",
              "data-settings":
                '{"background_background":"classic","sticky":"top","sticky_effects_offset":15,"animation":"fadeInDown","sticky_on":["desktop","tablet","mobile"],"sticky_offset":0}',
            },
          },
          [
            _c(
              "div",
              {
                staticClass: "elementor-container elementor-column-gap-default",
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-6ff996d wdp-sticky-section-no",
                    attrs: {
                      "data-id": "6ff996d",
                      "data-element_type": "column",
                    },
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-widget-wrap elementor-element-populated",
                      },
                      [
                        _c(
                          "section",
                          {
                            staticClass:
                              "elementor-section elementor-inner-section elementor-element elementor-element-1769e5b elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                            attrs: {
                              "data-id": "1769e5b",
                              "data-element_type": "section",
                            },
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-container elementor-column-gap-default",
                              },
                              [
                                _vm._m(9),
                                _vm._v(" "),
                                _vm._m(10),
                                _vm._v(" "),
                                _vm._m(11),
                                _vm._v(" "),
                                _vm._m(12),
                                _vm._v(" "),
                                _vm._m(13),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-9890fce wdp-sticky-section-no",
                                    attrs: {
                                      "data-id": "9890fce",
                                      "data-element_type": "column",
                                    },
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-widget-wrap elementor-element-populated",
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-element elementor-element-429c7ea elementor-align-right elementor-widget-tablet__width-initial elementor-widget__width-initial de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-button",
                                            attrs: {
                                              "data-id": "429c7ea",
                                              "data-element_type": "widget",
                                              "data-widget_type":
                                                "button.default",
                                            },
                                          },
                                          [
                                            _c(
                                              "div",
                                              {
                                                staticClass:
                                                  "elementor-widget-container",
                                              },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "elementor-button-wrapper",
                                                  },
                                                  [
                                                    _c(
                                                      "a",
                                                      {
                                                        staticClass:
                                                          "elementor-button elementor-button-link elementor-size-sm",
                                                        attrs: {
                                                          href: "https://wa.me/6283821877654",
                                                        },
                                                      },
                                                      [
                                                        _c(
                                                          "span",
                                                          {
                                                            staticClass:
                                                              "elementor-button-content-wrapper",
                                                          },
                                                          [
                                                            _c(
                                                              "span",
                                                              {
                                                                staticClass:
                                                                  "elementor-button-icon elementor-align-icon-right",
                                                              },
                                                              [
                                                                _c(
                                                                  "svg",
                                                                  {
                                                                    staticClass:
                                                                      "e-font-icon-svg e-fas-arrow-right",
                                                                    attrs: {
                                                                      "aria-hidden":
                                                                        "true",
                                                                      viewBox:
                                                                        "0 0 448 512",
                                                                      xmlns:
                                                                        "http://www.w3.org/2000/svg",
                                                                    },
                                                                  },
                                                                  [
                                                                    _c("path", {
                                                                      attrs: {
                                                                        d: "M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z",
                                                                      },
                                                                    }),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "span",
                                                              {
                                                                staticClass:
                                                                  "elementor-button-text",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "Gratis\n                                                                konsultasi"
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
        _vm._v(" "),
        _vm._m(14),
        _vm._v(" "),
        _vm._m(15),
        _vm._v(" "),
        _vm._m(16),
        _vm._v(" "),
        _vm._m(17),
        _vm._v(" "),
        _vm._m(18),
        _vm._v(" "),
        _vm._m(19),
        _vm._v(" "),
        _vm._m(20),
        _vm._v(" "),
        _vm._m(21),
        _vm._v(" "),
        _vm._m(22),
        _vm._v(" "),
        _vm._m(23),
        _vm._v(" "),
        _vm._m(24),
        _vm._v(" "),
        _vm._m(25),
        _vm._v(" "),
        _vm._m(26),
        _vm._v(" "),
        _c(
          "section",
          {
            staticClass:
              "elementor-section elementor-top-section elementor-element elementor-element-f51a0ac elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
            attrs: {
              "data-id": "f51a0ac",
              "data-element_type": "section",
              "data-settings": '{"background_background":"classic"}',
            },
          },
          [
            _c(
              "div",
              {
                staticClass: "elementor-container elementor-column-gap-default",
              },
              [
                _vm._m(27),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-9e76fbc wdp-sticky-section-no",
                    attrs: {
                      "data-id": "9e76fbc",
                      "data-element_type": "column",
                    },
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-widget-wrap elementor-element-populated",
                      },
                      [
                        _vm._m(28),
                        _vm._v(" "),
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-element elementor-element-8492eb4 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-page-list",
                            attrs: {
                              "data-id": "8492eb4",
                              "data-element_type": "widget",
                              "data-widget_type":
                                "elementskit-page-list.default",
                            },
                          },
                          [
                            _c(
                              "div",
                              { staticClass: "elementor-widget-container" },
                              [
                                _c("div", { staticClass: "ekit-wid-con" }, [
                                  _c(
                                    "div",
                                    {
                                      staticClass: "elementor-icon-list-items",
                                    },
                                    [
                                      _c(
                                        "div",
                                        {
                                          staticClass:
                                            "elementor-icon-list-item",
                                        },
                                        [
                                          _c(
                                            "a",
                                            {
                                              staticClass:
                                                "elementor-repeater-item-8d4e190 ekit_badge_left",
                                              attrs: {
                                                href: "https://wa.me/6283821877654",
                                                target: "_blank",
                                                rel: "nofollow",
                                              },
                                            },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "ekit_page_list_content",
                                                },
                                                [
                                                  _c(
                                                    "span",
                                                    {
                                                      staticClass:
                                                        "elementor-icon-list-icon",
                                                    },
                                                    [
                                                      _c(
                                                        "svg",
                                                        {
                                                          staticClass:
                                                            "e-font-icon-svg e-fab-whatsapp",
                                                          attrs: {
                                                            "aria-hidden":
                                                              "true",
                                                            viewBox:
                                                              "0 0 448 512",
                                                            xmlns:
                                                              "http://www.w3.org/2000/svg",
                                                          },
                                                        },
                                                        [
                                                          _c("path", {
                                                            attrs: {
                                                              d: "M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z",
                                                            },
                                                          }),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _vm._m(29),
                                                ]
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c(
                                        "div",
                                        {
                                          staticClass:
                                            "elementor-icon-list-item",
                                        },
                                        [
                                          _c(
                                            "a",
                                            {
                                              staticClass:
                                                "elementor-repeater-item-96a3a32 ekit_badge_left",
                                              attrs: {
                                                href: "https://mail.google.com/mail/u/0/?view=cm&tf=1&fs=1&to=lawofficeanas@gmail.com",
                                                target: "_blank",
                                                rel: "nofollow",
                                              },
                                            },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "ekit_page_list_content",
                                                },
                                                [
                                                  _c(
                                                    "span",
                                                    {
                                                      staticClass:
                                                        "elementor-icon-list-icon",
                                                    },
                                                    [
                                                      _c(
                                                        "svg",
                                                        {
                                                          staticClass:
                                                            "e-font-icon-svg e-far-envelope",
                                                          attrs: {
                                                            "aria-hidden":
                                                              "true",
                                                            viewBox:
                                                              "0 0 512 512",
                                                            xmlns:
                                                              "http://www.w3.org/2000/svg",
                                                          },
                                                        },
                                                        [
                                                          _c("path", {
                                                            attrs: {
                                                              d: "M464 64H48C21.49 64 0 85.49 0 112v288c0 26.51 21.49 48 48 48h416c26.51 0 48-21.49 48-48V112c0-26.51-21.49-48-48-48zm0 48v40.805c-22.422 18.259-58.168 46.651-134.587 106.49-16.841 13.247-50.201 45.072-73.413 44.701-23.208.375-56.579-31.459-73.413-44.701C106.18 199.465 70.425 171.067 48 152.805V112h416zM48 400V214.398c22.914 18.251 55.409 43.862 104.938 82.646 21.857 17.205 60.134 55.186 103.062 54.955 42.717.231 80.509-37.199 103.053-54.947 49.528-38.783 82.032-64.401 104.947-82.653V400H48z",
                                                            },
                                                          }),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                  _vm._v(" "),
                                                  _vm._m(30),
                                                ]
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _vm._m(31),
                                    ]
                                  ),
                                ]),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
                _vm._v(" "),
                _vm._m(32),
              ]
            ),
          ]
        ),
        _vm._v(" "),
        _vm._m(33),
      ]
    ),
    _vm._v(" "),
    _vm._m(34),
    _vm._v(" "),
    _vm._m(35),
  ])
}
var staticRenderFns = [
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-ca94340 wdp-sticky-section-no",
        attrs: { "data-id": "ca94340", "data-element_type": "column" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-widget-wrap elementor-element-populated" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-ed80058 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-image",
                attrs: {
                  "data-id": "ed80058",
                  "data-element_type": "widget",
                  "data-widget_type": "image.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c("img", {
                    staticClass: "attachment-large size-large wp-image-1869",
                    attrs: {
                      decoding: "async",
                      width: "126",
                      height: "80",
                      src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Partner_img-5-3.png",
                      alt: "",
                    },
                  }),
                ]),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "nav",
      {
        staticClass:
          "elementor-nav-menu--main elementor-nav-menu__container elementor-nav-menu--layout-horizontal e--pointer-underline e--animation-fade",
        attrs: { migration_allowed: "1", migrated: "0", role: "navigation" },
      },
      [
        _c(
          "ul",
          {
            staticClass: "elementor-nav-menu",
            attrs: {
              id: "menu-1-1c3bc99",
              "data-smartmenus-id": "1692859201075818",
            },
          },
          [
            _c(
              "li",
              {
                staticClass:
                  "menu-item menu-item-type-post_type menu-item-object-page menu-item-2151",
              },
              [
                _c(
                  "a",
                  {
                    staticClass: "elementor-item",
                    attrs: {
                      href: "https://anaslawoffice.dakreativ.com/team/",
                    },
                  },
                  [_vm._v("Team")]
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "li",
              {
                staticClass:
                  "menu-item menu-item-type-post_type menu-item-object-page menu-item-2304",
              },
              [
                _c(
                  "a",
                  {
                    staticClass: "elementor-item",
                    attrs: {
                      href: "https://anaslawoffice.dakreativ.com/about/",
                    },
                  },
                  [_vm._v("About")]
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "li",
              {
                staticClass:
                  "menu-item menu-item-type-post_type menu-item-object-page menu-item-2842",
              },
              [
                _c(
                  "a",
                  {
                    staticClass: "elementor-item",
                    attrs: {
                      href: "https://anaslawoffice.dakreativ.com/artikel/",
                    },
                  },
                  [_vm._v("Artikel-01")]
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "li",
              {
                staticClass:
                  "menu-item menu-item-type-post_type menu-item-object-page menu-item-2908",
              },
              [
                _c(
                  "a",
                  {
                    staticClass: "elementor-item",
                    attrs: {
                      href: "https://anaslawoffice.dakreativ.com/dakreativstudio/",
                    },
                  },
                  [_vm._v("Dakreativ Studio | Agency")]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "nav",
      {
        staticClass:
          "elementor-nav-menu--dropdown elementor-nav-menu__container",
        staticStyle: { top: "33px", width: "756px", left: "-237.8px" },
        attrs: { role: "navigation", "aria-hidden": "true" },
      },
      [
        _c(
          "ul",
          {
            staticClass: "elementor-nav-menu",
            attrs: {
              id: "menu-2-1c3bc99",
              "data-smartmenus-id": "16928592010775815",
            },
          },
          [
            _c(
              "li",
              {
                staticClass:
                  "menu-item menu-item-type-post_type menu-item-object-page menu-item-2151",
              },
              [
                _c(
                  "a",
                  {
                    staticClass: "elementor-item",
                    attrs: {
                      href: "https://anaslawoffice.dakreativ.com/team/",
                      tabindex: "-1",
                    },
                  },
                  [_vm._v("Team")]
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "li",
              {
                staticClass:
                  "menu-item menu-item-type-post_type menu-item-object-page menu-item-2304",
              },
              [
                _c(
                  "a",
                  {
                    staticClass: "elementor-item",
                    attrs: {
                      href: "https://anaslawoffice.dakreativ.com/about/",
                      tabindex: "-1",
                    },
                  },
                  [_vm._v("About")]
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "li",
              {
                staticClass:
                  "menu-item menu-item-type-post_type menu-item-object-page menu-item-2842",
              },
              [
                _c(
                  "a",
                  {
                    staticClass: "elementor-item",
                    attrs: {
                      href: "https://anaslawoffice.dakreativ.com/artikel/",
                      tabindex: "-1",
                    },
                  },
                  [_vm._v("Artikel-01")]
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "li",
              {
                staticClass:
                  "menu-item menu-item-type-post_type menu-item-object-page menu-item-2908",
              },
              [
                _c(
                  "a",
                  {
                    staticClass: "elementor-item",
                    attrs: {
                      href: "https://anaslawoffice.dakreativ.com/dakreativstudio/",
                      tabindex: "-1",
                    },
                  },
                  [_vm._v("Dakreativ Studio | Agency")]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-a263831 elementor-hidden-desktop elementor-hidden-tablet elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
        attrs: { "data-id": "a263831", "data-element_type": "section" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-323f694 wdp-sticky-section-no",
                attrs: { "data-id": "323f694", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-2e1f5c5 de_scroll_animation_no wdp-sticky-section-no elementor-invisible elementor-widget elementor-widget-elementskit-heading",
                        attrs: {
                          "data-id": "2e1f5c5",
                          "data-element_type": "widget",
                          "data-settings": '{"_animation":"slideInRight"}',
                          "data-widget_type": "elementskit-heading.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("div", { staticClass: "ekit-wid-con" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "ekit-heading elementskit-section-title-wraper text_center ekit_heading_tablet- ekit_heading_mobile-",
                                },
                                [
                                  _c(
                                    "h2",
                                    {
                                      staticClass:
                                        "ekit-heading--title elementskit-section-title",
                                    },
                                    [
                                      _vm._v("SERVICE "),
                                      _c("br"),
                                      _vm._v(
                                        "\n                                            INTERNET"
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-50 elementor-top-column elementor-element elementor-element-17622ae wdp-sticky-section-no",
                attrs: { "data-id": "17622ae", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-065baf8 animated-slow elementor-hidden-mobile de_scroll_animation_no wdp-sticky-section-no elementor-invisible elementor-widget elementor-widget-elementskit-funfact",
                        attrs: {
                          "data-id": "065baf8",
                          "data-element_type": "widget",
                          "data-settings":
                            '{"_animation":"fadeIn","_animation_delay":1000}',
                          "data-widget_type": "elementskit-funfact.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("div", { staticClass: "ekit-wid-con" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "elementskit-funfact text-center divider_funfact position_top",
                                },
                                [
                                  _c("div", {
                                    staticClass:
                                      "vertical-bar border_right_side",
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass: "elementskit-funfact-inner",
                                    },
                                    [
                                      _c(
                                        "div",
                                        { staticClass: "funfact-content" },
                                        [
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "number-percentage-wraper",
                                            },
                                            [
                                              _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "number-percentage",
                                                  attrs: {
                                                    "data-value": "165",
                                                    "data-animation-duration":
                                                      "3500",
                                                    "data-style": "static",
                                                  },
                                                },
                                                [_vm._v("165")]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "span",
                                                { staticClass: "super" },
                                                [_vm._v("+")]
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "h3",
                                            { staticClass: "funfact-title" },
                                            [_vm._v("Support Given")]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-c0eab1b de_scroll_animation_no wdp-sticky-section-no elementor-invisible elementor-widget elementor-widget-elementskit-heading",
                        attrs: {
                          "data-id": "c0eab1b",
                          "data-element_type": "widget",
                          "data-settings": '{"_animation":"slideInLeft"}',
                          "data-widget_type": "elementskit-heading.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("div", { staticClass: "ekit-wid-con" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "ekit-heading elementskit-section-title-wraper text_center ekit_heading_tablet- ekit_heading_mobile-",
                                },
                                [
                                  _c(
                                    "h2",
                                    {
                                      staticClass:
                                        "ekit-heading--title elementskit-section-title",
                                    },
                                    [
                                      _vm._v("MOBILE "),
                                      _c("br"),
                                      _vm._v(
                                        " APPS\n                                        "
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-47f38fd elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                        attrs: {
                          "data-id": "47f38fd",
                          "data-element_type": "section",
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-9432f0f wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "9432f0f",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c("div", {
                                  staticClass: "elementor-widget-wrap",
                                }),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-73735f1 wdp-sticky-section-no",
        attrs: { "data-id": "73735f1", "data-element_type": "column" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-widget-wrap elementor-element-populated" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-0cae2ed elementor-widget-tablet__width-initial elementor-widget__width-initial de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-image",
                attrs: {
                  "data-id": "0cae2ed",
                  "data-element_type": "widget",
                  "data-widget_type": "image.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c("a", { attrs: { href: "https://anaslawoffice.com" } }, [
                    _c("img", {
                      staticClass: "attachment-large size-large wp-image-2351",
                      attrs: {
                        decoding: "async",
                        width: "86",
                        height: "80",
                        src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/client_1_white.png",
                        alt: "",
                        srcset:
                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/client_1_white.png" +
                          " 86w, " +
                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/client_1_white-13x12.png" +
                          " 13w",
                        sizes: "(max-width: 86px) 100vw, 86px",
                      },
                    }),
                  ]),
                ]),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-e9a5a52 wdp-sticky-section-no",
        attrs: { "data-id": "e9a5a52", "data-element_type": "column" },
      },
      [_c("div", { staticClass: "elementor-widget-wrap" })]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-18cd367 wdp-sticky-section-no",
        attrs: { "data-id": "18cd367", "data-element_type": "column" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-widget-wrap elementor-element-populated" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-31c1ea4 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-heading",
                attrs: {
                  "data-id": "31c1ea4",
                  "data-element_type": "widget",
                  "data-widget_type": "heading.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c(
                    "h2",
                    {
                      staticClass:
                        "elementor-heading-title elementor-size-default",
                    },
                    [
                      _c("a", { attrs: { href: "#layanan" } }, [
                        _vm._v("Branda"),
                      ]),
                    ]
                  ),
                ]),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-7d037a3 wdp-sticky-section-no",
        attrs: { "data-id": "7d037a3", "data-element_type": "column" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-widget-wrap elementor-element-populated" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-5d32f12 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-heading",
                attrs: {
                  "data-id": "5d32f12",
                  "data-element_type": "widget",
                  "data-widget_type": "heading.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c(
                    "h2",
                    {
                      staticClass:
                        "elementor-heading-title elementor-size-default",
                    },
                    [
                      _c("a", { attrs: { href: "#layanan" } }, [
                        _vm._v("Artikel"),
                      ]),
                    ]
                  ),
                ]),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-3923071 wdp-sticky-section-no",
        attrs: { "data-id": "3923071", "data-element_type": "column" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-widget-wrap elementor-element-populated" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-bf18c9f de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-heading",
                attrs: {
                  "data-id": "bf18c9f",
                  "data-element_type": "widget",
                  "data-widget_type": "heading.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c(
                    "h2",
                    {
                      staticClass:
                        "elementor-heading-title elementor-size-default",
                    },
                    [
                      _c("a", { attrs: { href: "#layanan" } }, [
                        _vm._v("Service"),
                      ]),
                    ]
                  ),
                ]),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-73735f1 wdp-sticky-section-no",
        attrs: { "data-id": "73735f1", "data-element_type": "column" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-widget-wrap elementor-element-populated" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-0cae2ed elementor-widget-tablet__width-initial elementor-widget__width-initial de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-image",
                attrs: {
                  "data-id": "0cae2ed",
                  "data-element_type": "widget",
                  "data-widget_type": "image.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c("a", { attrs: { href: "https://anaslawoffice.com" } }, [
                    _c("img", {
                      staticClass: "attachment-large size-large wp-image-2351",
                      attrs: {
                        decoding: "async",
                        width: "86",
                        height: "80",
                        src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/client_1_white.png",
                        alt: "",
                        srcset:
                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/client_1_white.png" +
                          " 86w, " +
                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/client_1_white-13x12.png" +
                          " 13w",
                        sizes: "(max-width: 86px) 100vw, 86px",
                      },
                    }),
                  ]),
                ]),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-e9a5a52 wdp-sticky-section-no",
        attrs: { "data-id": "e9a5a52", "data-element_type": "column" },
      },
      [_c("div", { staticClass: "elementor-widget-wrap" })]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-18cd367 wdp-sticky-section-no",
        attrs: { "data-id": "18cd367", "data-element_type": "column" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-widget-wrap elementor-element-populated" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-31c1ea4 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-heading",
                attrs: {
                  "data-id": "31c1ea4",
                  "data-element_type": "widget",
                  "data-widget_type": "heading.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c(
                    "h2",
                    {
                      staticClass:
                        "elementor-heading-title elementor-size-default",
                    },
                    [
                      _c("a", { attrs: { href: "#layanan" } }, [
                        _vm._v("Branda"),
                      ]),
                    ]
                  ),
                ]),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-7d037a3 wdp-sticky-section-no",
        attrs: { "data-id": "7d037a3", "data-element_type": "column" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-widget-wrap elementor-element-populated" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-5d32f12 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-heading",
                attrs: {
                  "data-id": "5d32f12",
                  "data-element_type": "widget",
                  "data-widget_type": "heading.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c(
                    "h2",
                    {
                      staticClass:
                        "elementor-heading-title elementor-size-default",
                    },
                    [
                      _c("a", { attrs: { href: "#layanan" } }, [
                        _vm._v("Artikel"),
                      ]),
                    ]
                  ),
                ]),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-16 elementor-inner-column elementor-element elementor-element-3923071 wdp-sticky-section-no",
        attrs: { "data-id": "3923071", "data-element_type": "column" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-widget-wrap elementor-element-populated" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-bf18c9f de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-heading",
                attrs: {
                  "data-id": "bf18c9f",
                  "data-element_type": "widget",
                  "data-widget_type": "heading.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c(
                    "h2",
                    {
                      staticClass:
                        "elementor-heading-title elementor-size-default",
                    },
                    [
                      _c("a", { attrs: { href: "#layanan" } }, [
                        _vm._v("Service"),
                      ]),
                    ]
                  ),
                ]),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-1b03b00 elementor-hidden-desktop elementor-hidden-tablet elementor-hidden-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
        attrs: { "data-id": "1b03b00", "data-element_type": "section" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-a422b54 wdp-sticky-section-no",
                attrs: { "data-id": "a422b54", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-1589180 animated-fast de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-image",
                        attrs: {
                          "data-id": "1589180",
                          "data-element_type": "widget",
                          "data-settings": '{"_animation":"none"}',
                          "data-widget_type": "image.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("img", {
                              staticClass:
                                "attachment-large size-large wp-image-1859",
                              attrs: {
                                decoding: "async",
                                fetchpriority: "high",
                                width: "514",
                                height: "548",
                                src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/fak-mobile.png",
                                alt: "",
                                srcset:
                                  "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/fak-mobile.png" +
                                  " 514w, " +
                                  "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/fak-mobile-281x300.png" +
                                  " 281w",
                                sizes: "(max-width: 514px) 100vw, 514px",
                              },
                            }),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-2d1d5e7 elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle wdp-sticky-section-no lazyloaded",
        attrs: {
          "data-id": "2d1d5e7",
          "data-element_type": "section",
          "data-settings": '{"background_background":"classic"}',
          "data-e-bg-lazyload": "",
        },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-295066f wdp-sticky-section-no",
                attrs: { "data-id": "295066f", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-2acf6b9c elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                        attrs: {
                          "data-id": "2acf6b9c",
                          "data-element_type": "section",
                          "data-settings":
                            '{"background_background":"classic"}',
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-59ae4476 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "59ae4476",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-2ad17c92 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-heading",
                                        attrs: {
                                          "data-id": "2ad17c92",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-heading.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "ekit-heading elementskit-section-title-wraper text_left ekit_heading_tablet- ekit_heading_mobile-",
                                                  },
                                                  [
                                                    _c(
                                                      "h2",
                                                      {
                                                        staticClass:
                                                          "ekit-heading--title elementskit-section-title",
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n                                                            Take your website to next level"
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "ekit-heading__description",
                                                      },
                                                      [
                                                        _c("p", [
                                                          _vm._v(
                                                            "It is beautifully designed in a very smart way to\n                                                                bring the best user experience that you will love.\n                                                            "
                                                          ),
                                                        ]),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-6ae88917 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-button",
                                        attrs: {
                                          "data-id": "6ae88917",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-button.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "ekit-btn-wraper",
                                                  },
                                                  [
                                                    _c(
                                                      "a",
                                                      {
                                                        staticClass:
                                                          "elementskit-btn whitespace--normal",
                                                        attrs: { href: "#" },
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n\n\n                                                            Read More "
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-6466867b wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "6466867b",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c("div", {
                                  staticClass: "elementor-widget-wrap",
                                }),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-25039ae7 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
        attrs: { "data-id": "25039ae7", "data-element_type": "section" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-114cb46a wdp-sticky-section-no",
                attrs: { "data-id": "114cb46a", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-4904c561 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                        attrs: {
                          "data-id": "4904c561",
                          "data-element_type": "section",
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-70615201 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "70615201",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-81edb90 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-heading animated fadeInUp",
                                        attrs: {
                                          "data-id": "81edb90",
                                          "data-element_type": "widget",
                                          "data-settings":
                                            '{"_animation":"fadeInUp"}',
                                          "data-widget_type":
                                            "elementskit-heading.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "ekit-heading elementskit-section-title-wraper center ekit_heading_tablet- ekit_heading_mobile-",
                                                  },
                                                  [
                                                    _c(
                                                      "h2",
                                                      {
                                                        staticClass:
                                                          "ekit-heading--title elementskit-section-title",
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n                                                            Our Service"
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "ekit-heading__description",
                                                      },
                                                      [
                                                        _c("p", [
                                                          _vm._v(
                                                            "A small river named Duden flows by their place and\n                                                                supplies it with the necessary regelialia. It is a\n                                                                paradise"
                                                          ),
                                                        ]),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-3f49b14b elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                        attrs: {
                          "data-id": "3f49b14b",
                          "data-element_type": "section",
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-58809e9d wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "58809e9d",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-694a6bad ekit-equal-height-disable de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-icon-box animated fadeInUp",
                                        attrs: {
                                          "data-id": "694a6bad",
                                          "data-element_type": "widget",
                                          "data-settings":
                                            '{"_animation":"fadeInUp"}',
                                          "data-widget_type":
                                            "elementskit-icon-box.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "a",
                                                  {
                                                    staticClass:
                                                      "ekit_global_links",
                                                    attrs: {
                                                      href: "#",
                                                      target: "_self",
                                                      rel: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-infobox text-center text- icon-top-align elementor-animation-",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-box-header elementor-animation-",
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-icon",
                                                              },
                                                              [
                                                                _c("i", {
                                                                  staticClass:
                                                                    "elementkit-infobox-icon fasicon icon-app",
                                                                  attrs: {
                                                                    "aria-hidden":
                                                                      "true",
                                                                  },
                                                                }),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "box-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h3",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Akun Whitelist Facebook "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("p", [
                                                              _vm._v(
                                                                "Far far away, behind the word moun\n                                                                    far from the countries"
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-fdde176 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "fdde176",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-3e0e6a7 ekit-equal-height-disable de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-icon-box animated fadeInUp",
                                        attrs: {
                                          "data-id": "3e0e6a7",
                                          "data-element_type": "widget",
                                          "data-settings":
                                            '{"_animation":"fadeInUp"}',
                                          "data-widget_type":
                                            "elementskit-icon-box.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "a",
                                                  {
                                                    staticClass:
                                                      "ekit_global_links",
                                                    attrs: {
                                                      href: "#",
                                                      target: "_self",
                                                      rel: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-infobox text-center text- icon-top-align elementor-animation-",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-box-header elementor-animation-",
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-icon",
                                                              },
                                                              [
                                                                _c("i", {
                                                                  staticClass:
                                                                    "elementkit-infobox-icon fasicon icon-app",
                                                                  attrs: {
                                                                    "aria-hidden":
                                                                      "true",
                                                                  },
                                                                }),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "box-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h3",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Akun Whitelist Google "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("p", [
                                                              _vm._v(
                                                                "Far far away, behind the word moun\n                                                                    far from the countries"
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-2458984f elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
        attrs: { "data-id": "2458984f", "data-element_type": "section" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-dd9f385 wdp-sticky-section-no",
                attrs: { "data-id": "dd9f385", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-7eb3e754 elementor-section-content-middle elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no animated fadeInUp",
                        attrs: {
                          "data-id": "7eb3e754",
                          "data-element_type": "section",
                          "data-settings": '{"animation":"fadeInUp"}',
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-66b3e01e wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "66b3e01e",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-4e223380 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-heading",
                                        attrs: {
                                          "data-id": "4e223380",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-heading.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "ekit-heading elementskit-section-title-wraper text_left ekit_heading_tablet- ekit_heading_mobile-",
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "ekit_heading_separetor_wraper ekit_heading_elementskit-border-divider",
                                                      },
                                                      [
                                                        _c("div", {
                                                          staticClass:
                                                            "elementskit-border-divider",
                                                        }),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "h2",
                                                      {
                                                        staticClass:
                                                          "ekit-heading--title elementskit-section-title",
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n                                                            Penjelasan Singkat Tentang Agency"
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "ekit-heading__description",
                                                      },
                                                      [
                                                        _c("p", [
                                                          _vm._v(
                                                            "Behind the word mountains, far from the countries\n                                                                Vokalia and Consonantia, there live the blind texts.\n                                                                Separated they live arts Bookmark grove right at the\n                                                                coast without compromising our"
                                                          ),
                                                          _c("br"),
                                                          _vm._v(
                                                            "\n                                                                we do in the world of finance."
                                                          ),
                                                        ]),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-4433e5 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-video",
                                        attrs: {
                                          "data-id": "4433e5",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-video.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "video-content",
                                                    attrs: {
                                                      "data-video-player":
                                                        '["duration"]',
                                                      "data-video-setting":
                                                        '{"videoVolume":"horizontal","startVolume":0.8,"videoType":"iframe","videoClass":"mfp-fade"}',
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "a",
                                                      {
                                                        staticClass:
                                                          "ekit_icon_button glow-btn ekit-video-popup ekit-video-popup-btn",
                                                        attrs: {
                                                          href: "https://www.youtube.com/embed/T-fXzUsPZtM?feature=oembed?playlist=T-fXzUsPZtM&mute=0&autoplay=0&loop=no&controls=0&start=0&end=",
                                                          "aria-label":
                                                            "video-popup",
                                                        },
                                                      },
                                                      [
                                                        _c("i", {
                                                          staticClass:
                                                            "fasicon icon-play-button",
                                                          attrs: {
                                                            "aria-hidden":
                                                              "true",
                                                          },
                                                        }),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4cfa4810 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "4cfa4810",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-623637c5 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-image",
                                        attrs: {
                                          "data-id": "623637c5",
                                          "data-element_type": "widget",
                                          "data-widget_type": "image.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c("img", {
                                              attrs: {
                                                decoding: "async",
                                                src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/left_image.png",
                                                title: "left_image.png",
                                                alt: "left_image.png",
                                                loading: "lazy",
                                              },
                                            }),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-3aea5899 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
        attrs: {
          "data-id": "3aea5899",
          "data-element_type": "section",
          "data-settings": '{"background_background":"classic"}',
        },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-56d27f30 wdp-sticky-section-no",
                attrs: { "data-id": "56d27f30", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-34b05882 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                        attrs: {
                          "data-id": "34b05882",
                          "data-element_type": "section",
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-37180b wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "37180b",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-2d5ea27c de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-heading animated fadeInUp",
                                        attrs: {
                                          "data-id": "2d5ea27c",
                                          "data-element_type": "widget",
                                          "data-settings":
                                            '{"_animation":"fadeInUp"}',
                                          "data-widget_type":
                                            "elementskit-heading.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "ekit-heading elementskit-section-title-wraper center ekit_heading_tablet- ekit_heading_mobile-",
                                                  },
                                                  [
                                                    _c(
                                                      "h2",
                                                      {
                                                        staticClass:
                                                          "ekit-heading--title elementskit-section-title",
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n                                                            Benefit Special Lainnya"
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "ekit-heading__description",
                                                      },
                                                      [
                                                        _c("p", [
                                                          _vm._v(
                                                            "A small river named Duden flows by their place and\n                                                                supplies it with the necessary regelialia. It is a\n                                                                paradise"
                                                          ),
                                                        ]),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-4774a63c elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no animated fadeInUp",
                        attrs: {
                          "data-id": "4774a63c",
                          "data-element_type": "section",
                          "data-settings": '{"animation":"fadeInUp"}',
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-6d3dd579 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "6d3dd579",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-2a2eaa48 ekit-equal-height-disable de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-icon-box",
                                        attrs: {
                                          "data-id": "2a2eaa48",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-icon-box.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "a",
                                                  {
                                                    staticClass:
                                                      "ekit_global_links",
                                                    attrs: {
                                                      href: "#",
                                                      target: "_self",
                                                      rel: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-box-header elementor-animation-",
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-icon text-center",
                                                              },
                                                              [
                                                                _c("i", {
                                                                  staticClass:
                                                                    "elementkit-infobox-icon fasicon icon-layers1",
                                                                  attrs: {
                                                                    "aria-hidden":
                                                                      "true",
                                                                  },
                                                                }),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "box-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h3",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Organised Code "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("p", [
                                                              _vm._v(
                                                                "A mobile app landing page is the important and\n                                                                    essentials amount product."
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-7d8e165 ekit-equal-height-disable de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-icon-box",
                                        attrs: {
                                          "data-id": "7d8e165",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-icon-box.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "a",
                                                  {
                                                    staticClass:
                                                      "ekit_global_links",
                                                    attrs: {
                                                      href: "#",
                                                      target: "_self",
                                                      rel: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-box-header elementor-animation-",
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-icon text-center",
                                                              },
                                                              [
                                                                _c("i", {
                                                                  staticClass:
                                                                    "elementkit-infobox-icon fasicon icon-layers1",
                                                                  attrs: {
                                                                    "aria-hidden":
                                                                      "true",
                                                                  },
                                                                }),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "box-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h3",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Organised Code "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("p", [
                                                              _vm._v(
                                                                "A mobile app landing page is the important and\n                                                                    essentials amount product."
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-e64ad86 ekit-equal-height-disable de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-icon-box",
                                        attrs: {
                                          "data-id": "e64ad86",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-icon-box.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "a",
                                                  {
                                                    staticClass:
                                                      "ekit_global_links",
                                                    attrs: {
                                                      href: "#",
                                                      target: "_self",
                                                      rel: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-box-header elementor-animation-",
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-icon text-center",
                                                              },
                                                              [
                                                                _c("i", {
                                                                  staticClass:
                                                                    "elementkit-infobox-icon fasicon icon-layers1",
                                                                  attrs: {
                                                                    "aria-hidden":
                                                                      "true",
                                                                  },
                                                                }),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "box-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h3",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Organised Code "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("p", [
                                                              _vm._v(
                                                                "A mobile app landing page is the important and\n                                                                    essentials amount product."
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-880d8a4 ekit-equal-height-disable de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-icon-box",
                                        attrs: {
                                          "data-id": "880d8a4",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-icon-box.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "a",
                                                  {
                                                    staticClass:
                                                      "ekit_global_links",
                                                    attrs: {
                                                      href: "#",
                                                      target: "_self",
                                                      rel: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-box-header elementor-animation-",
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-icon text-center",
                                                              },
                                                              [
                                                                _c("i", {
                                                                  staticClass:
                                                                    "elementkit-infobox-icon fasicon icon-layers1",
                                                                  attrs: {
                                                                    "aria-hidden":
                                                                      "true",
                                                                  },
                                                                }),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "box-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h3",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Organised Code "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("p", [
                                                              _vm._v(
                                                                "A mobile app landing page is the important and\n                                                                    essentials amount product."
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-7e91a68 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "7e91a68",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-89b25ef ekit-equal-height-disable de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-icon-box",
                                        attrs: {
                                          "data-id": "89b25ef",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-icon-box.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "a",
                                                  {
                                                    staticClass:
                                                      "ekit_global_links",
                                                    attrs: {
                                                      href: "#",
                                                      target: "_self",
                                                      rel: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-box-header elementor-animation-",
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-icon text-center",
                                                              },
                                                              [
                                                                _c("i", {
                                                                  staticClass:
                                                                    "elementkit-infobox-icon fasicon icon-layers1",
                                                                  attrs: {
                                                                    "aria-hidden":
                                                                      "true",
                                                                  },
                                                                }),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "box-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h3",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Organised Code "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("p", [
                                                              _vm._v(
                                                                "A mobile app landing page is the important and\n                                                                    essentials amount product."
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-590b284 ekit-equal-height-disable de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-icon-box",
                                        attrs: {
                                          "data-id": "590b284",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-icon-box.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "a",
                                                  {
                                                    staticClass:
                                                      "ekit_global_links",
                                                    attrs: {
                                                      href: "#",
                                                      target: "_self",
                                                      rel: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-box-header elementor-animation-",
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-icon text-center",
                                                              },
                                                              [
                                                                _c("i", {
                                                                  staticClass:
                                                                    "elementkit-infobox-icon fasicon icon-layers1",
                                                                  attrs: {
                                                                    "aria-hidden":
                                                                      "true",
                                                                  },
                                                                }),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "box-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h3",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Organised Code "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("p", [
                                                              _vm._v(
                                                                "A mobile app landing page is the important and\n                                                                    essentials amount product."
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-ff3e6ca ekit-equal-height-disable de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-icon-box",
                                        attrs: {
                                          "data-id": "ff3e6ca",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-icon-box.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "a",
                                                  {
                                                    staticClass:
                                                      "ekit_global_links",
                                                    attrs: {
                                                      href: "#",
                                                      target: "_self",
                                                      rel: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-box-header elementor-animation-",
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-icon text-center",
                                                              },
                                                              [
                                                                _c("i", {
                                                                  staticClass:
                                                                    "elementkit-infobox-icon fasicon icon-layers1",
                                                                  attrs: {
                                                                    "aria-hidden":
                                                                      "true",
                                                                  },
                                                                }),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "box-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h3",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Organised Code "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("p", [
                                                              _vm._v(
                                                                "A mobile app landing page is the important and\n                                                                    essentials amount product."
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-3b5d0c6 ekit-equal-height-disable de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-icon-box",
                                        attrs: {
                                          "data-id": "3b5d0c6",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-icon-box.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "a",
                                                  {
                                                    staticClass:
                                                      "ekit_global_links",
                                                    attrs: {
                                                      href: "#",
                                                      target: "_self",
                                                      rel: "",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-infobox text- text-left icon-lef-right-aligin elementor-animation- media",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-box-header elementor-animation-",
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-icon text-center",
                                                              },
                                                              [
                                                                _c("i", {
                                                                  staticClass:
                                                                    "elementkit-infobox-icon fasicon icon-layers1",
                                                                  attrs: {
                                                                    "aria-hidden":
                                                                      "true",
                                                                  },
                                                                }),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "box-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h3",
                                                              {
                                                                staticClass:
                                                                  "elementskit-info-box-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Organised Code "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("p", [
                                                              _vm._v(
                                                                "A mobile app landing page is the important and\n                                                                    essentials amount product."
                                                              ),
                                                            ]),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-0da7745 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
        attrs: { "data-id": "0da7745", "data-element_type": "section" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-ac67fed wdp-sticky-section-no",
                attrs: { "data-id": "ac67fed", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-420faf2 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-heading animated fadeInUp",
                        attrs: {
                          "data-id": "420faf2",
                          "data-element_type": "widget",
                          "data-settings": '{"_animation":"fadeInUp"}',
                          "data-widget_type": "elementskit-heading.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("div", { staticClass: "ekit-wid-con" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "ekit-heading elementskit-section-title-wraper center ekit_heading_tablet- ekit_heading_mobile-",
                                },
                                [
                                  _c(
                                    "h2",
                                    {
                                      staticClass:
                                        "ekit-heading--title elementskit-section-title",
                                    },
                                    [
                                      _vm._v(
                                        "Pricelist\n                                            "
                                      ),
                                      _c("span"),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass: "ekit-heading__description",
                                    },
                                    [
                                      _c("p", [
                                        _vm._v(
                                          "A small river named Duden flows by their place and supplies it with\n                                                the necessary regelialia. It is a paradise"
                                        ),
                                      ]),
                                    ]
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-2a2b03e8 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no animated slideInUp",
                        attrs: {
                          "data-id": "2a2b03e8",
                          "data-element_type": "section",
                          "data-settings": '{"animation":"slideInUp"}',
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-28e9b222 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "28e9b222",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-1bbffc1e de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-pricing",
                                        attrs: {
                                          "data-id": "1bbffc1e",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-pricing.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "elementskit-single-pricing",
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-header",
                                                      },
                                                      [
                                                        _c(
                                                          "h3",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-title",
                                                          },
                                                          [_vm._v("Starter ")]
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-price-wraper has-tag",
                                                      },
                                                      [
                                                        _c("div", {
                                                          staticClass:
                                                            "elementskit-pricing-tag",
                                                        }),
                                                        _vm._v(" "),
                                                        _c(
                                                          "span",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-price",
                                                          },
                                                          [
                                                            _c(
                                                              "sup",
                                                              {
                                                                staticClass:
                                                                  "currency",
                                                              },
                                                              [_vm._v("$")]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("span", [
                                                              _vm._v("5.99"),
                                                            ]),
                                                            _vm._v(" "),
                                                            _c(
                                                              "sub",
                                                              {
                                                                staticClass:
                                                                  "period",
                                                              },
                                                              [_vm._v("Month")]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-content",
                                                      },
                                                      [
                                                        _c(
                                                          "ul",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-lists",
                                                          },
                                                          [
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-524a2ba",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    15 Email Account\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-61572a8",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    100 GB Space\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-14baa04",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    1 Domain Name\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-4d6ce20",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    300 GB Bandwidth\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-04cbf73",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    00 Mysql Databases\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-2eced6a",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    Enhanced Security\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-btn-wraper",
                                                      },
                                                      [
                                                        _c(
                                                          "a",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-btn ekit-pricing-btn-icon-pos-left",
                                                            attrs: {
                                                              href: "#",
                                                            },
                                                          },
                                                          [
                                                            _vm._v(
                                                              "\n                                                                Learn more "
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-21302bb0 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "21302bb0",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-4a7a62aa de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-pricing",
                                        attrs: {
                                          "data-id": "4a7a62aa",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-pricing.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "elementskit-single-pricing",
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-header",
                                                      },
                                                      [
                                                        _c(
                                                          "h3",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-title",
                                                          },
                                                          [_vm._v("Starter ")]
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-price-wraper has-tag",
                                                      },
                                                      [
                                                        _c("div", {
                                                          staticClass:
                                                            "elementskit-pricing-tag",
                                                        }),
                                                        _vm._v(" "),
                                                        _c(
                                                          "span",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-price",
                                                          },
                                                          [
                                                            _c(
                                                              "sup",
                                                              {
                                                                staticClass:
                                                                  "currency",
                                                              },
                                                              [_vm._v("$")]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("span", [
                                                              _vm._v("5.99"),
                                                            ]),
                                                            _vm._v(" "),
                                                            _c(
                                                              "sub",
                                                              {
                                                                staticClass:
                                                                  "period",
                                                              },
                                                              [_vm._v("Month")]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-content",
                                                      },
                                                      [
                                                        _c(
                                                          "ul",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-lists",
                                                          },
                                                          [
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-524a2ba",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    15 Email Account\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-61572a8",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    100 GB Space\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-14baa04",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    1 Domain Name\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-4d6ce20",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    300 GB Bandwidth\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-04cbf73",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    00 Mysql Databases\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-2eced6a",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    Enhanced Security\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-btn-wraper",
                                                      },
                                                      [
                                                        _c(
                                                          "a",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-btn ekit-pricing-btn-icon-pos-left",
                                                            attrs: {
                                                              href: "#",
                                                            },
                                                          },
                                                          [
                                                            _vm._v(
                                                              "\n                                                                Learn more "
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-33 elementor-inner-column elementor-element elementor-element-576ffcf7 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "576ffcf7",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-6a96b9b de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-pricing",
                                        attrs: {
                                          "data-id": "6a96b9b",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-pricing.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "elementskit-single-pricing",
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-header",
                                                      },
                                                      [
                                                        _c(
                                                          "h3",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-title",
                                                          },
                                                          [_vm._v("Starter ")]
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-price-wraper has-tag",
                                                      },
                                                      [
                                                        _c("div", {
                                                          staticClass:
                                                            "elementskit-pricing-tag",
                                                        }),
                                                        _vm._v(" "),
                                                        _c(
                                                          "span",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-price",
                                                          },
                                                          [
                                                            _c(
                                                              "sup",
                                                              {
                                                                staticClass:
                                                                  "currency",
                                                              },
                                                              [_vm._v("$")]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("span", [
                                                              _vm._v("5.99"),
                                                            ]),
                                                            _vm._v(" "),
                                                            _c(
                                                              "sub",
                                                              {
                                                                staticClass:
                                                                  "period",
                                                              },
                                                              [_vm._v("Month")]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-content",
                                                      },
                                                      [
                                                        _c(
                                                          "ul",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-lists",
                                                          },
                                                          [
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-524a2ba",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    15 Email Account\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-61572a8",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    100 GB Space\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-14baa04",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    1 Domain Name\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-4d6ce20",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    300 GB Bandwidth\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-04cbf73",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    00 Mysql Databases\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "li",
                                                              {
                                                                staticClass:
                                                                  "elementor-repeater-item-2eced6a",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n\n                                                                    Enhanced Security\n                                                                "
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-pricing-btn-wraper",
                                                      },
                                                      [
                                                        _c(
                                                          "a",
                                                          {
                                                            staticClass:
                                                              "elementskit-pricing-btn ekit-pricing-btn-icon-pos-left",
                                                            attrs: {
                                                              href: "#",
                                                            },
                                                          },
                                                          [
                                                            _vm._v(
                                                              "\n                                                                Learn more "
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-41893c4f elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
        attrs: {
          "data-id": "41893c4f",
          "data-element_type": "section",
          "data-settings": '{"background_background":"classic"}',
        },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-5a52adbf wdp-sticky-section-no",
                attrs: { "data-id": "5a52adbf", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-222e885f elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                        attrs: {
                          "data-id": "222e885f",
                          "data-element_type": "section",
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-29649a8e wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "29649a8e",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-2a5855cd de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-heading animated fadeInUp",
                                        attrs: {
                                          "data-id": "2a5855cd",
                                          "data-element_type": "widget",
                                          "data-settings":
                                            '{"_animation":"fadeInUp"}',
                                          "data-widget_type":
                                            "elementskit-heading.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "ekit-heading elementskit-section-title-wraper center ekit_heading_tablet- ekit_heading_mobile-",
                                                  },
                                                  [
                                                    _c(
                                                      "h2",
                                                      {
                                                        staticClass:
                                                          "ekit-heading--title elementskit-section-title",
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n                                                            Testimony "
                                                        ),
                                                        _c("span", [
                                                          _vm._v("Customers"),
                                                        ]),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "ekit-heading__description",
                                                      },
                                                      [
                                                        _c("p", [
                                                          _vm._v(
                                                            "A small river named Duden flows by their place and\n                                                                supplies it with the necessary regelialia. It is a\n                                                                paradise"
                                                          ),
                                                        ]),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-66b8156 elementor-section-height-min-height elementor-section-boxed elementor-section-height-default elementor-section-items-middle wdp-sticky-section-no lazyloaded",
        attrs: {
          "data-id": "66b8156",
          "data-element_type": "section",
          "data-settings": '{"background_background":"classic"}',
          "data-e-bg-lazyload": "",
        },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-3380fbe wdp-sticky-section-no",
                attrs: { "data-id": "3380fbe", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-9c08e39 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                        attrs: {
                          "data-id": "9c08e39",
                          "data-element_type": "section",
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-c289a0d wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "c289a0d",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c("div", {
                                  staticClass: "elementor-widget-wrap",
                                }),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-22c19ef wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "22c19ef",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-0ea8a3d de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-testimonial",
                                        attrs: {
                                          "data-id": "0ea8a3d",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-testimonial.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "elementskit-testimonial-slider ekit_testimonial_style_5 arrow_inside",
                                                    attrs: {
                                                      "data-config":
                                                        '{"rtl":false,"arrows":true,"dots":false,"pauseOnHover":true,"autoplay":false,"speed":1000,"slidesPerGroup":1,"slidesPerView":1,"loop":false,"breakpoints":{"320":{"slidesPerView":1,"slidesPerGroup":1,"spaceBetween":10},"768":{"slidesPerView":2,"slidesPerGroup":1,"spaceBetween":10},"1024":{"slidesPerView":1,"slidesPerGroup":1,"spaceBetween":15}}}',
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "ekit-main-swiper swiper swiper-container-initialized swiper-container-horizontal",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "swiper-wrapper",
                                                            staticStyle: {
                                                              transform:
                                                                "translate3d(0px, 0px, 0px)",
                                                            },
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "swiper-slide swiper-slide-active",
                                                                staticStyle: {
                                                                  width:
                                                                    "419px",
                                                                  "margin-right":
                                                                    "10px",
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "div",
                                                                  {
                                                                    staticClass:
                                                                      "swiper-slide-inner",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "div",
                                                                      {
                                                                        staticClass:
                                                                          "elementskit-single-testimonial-slider elementskit-testimonial-slider-block-style elementskit-testimonial-slider-block-style-two elementor-repeater-item-71ca779",
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "div",
                                                                          {
                                                                            staticClass:
                                                                              "elementskit-commentor-header",
                                                                          }
                                                                        ),
                                                                        _vm._v(
                                                                          " "
                                                                        ),
                                                                        _c(
                                                                          "div",
                                                                          {
                                                                            staticClass:
                                                                              "elementskit-commentor-content",
                                                                          },
                                                                          [
                                                                            _c(
                                                                              "p",
                                                                              [
                                                                                _vm._v(
                                                                                  "View some of our work and case\n                                                                                    studies for clients. We will\n                                                                                    work to deliver that strategy by\n                                                                                    building out your existing\n                                                                                    campaigns, or establishing\n                                                                                    accounts at new networks. It’s\n                                                                                    important to us that you."
                                                                                ),
                                                                              ]
                                                                            ),
                                                                          ]
                                                                        ),
                                                                        _vm._v(
                                                                          " "
                                                                        ),
                                                                        _c(
                                                                          "div",
                                                                          {
                                                                            staticClass:
                                                                              "elementskit-commentor-bio",
                                                                          },
                                                                          [
                                                                            _c(
                                                                              "div",
                                                                              {
                                                                                staticClass:
                                                                                  "elementkit-commentor-details client_left",
                                                                              },
                                                                              [
                                                                                _c(
                                                                                  "div",
                                                                                  {
                                                                                    staticClass:
                                                                                      "elementskit-commentor-image ekit-testimonial--avatar",
                                                                                  },
                                                                                  [
                                                                                    _c(
                                                                                      "img",
                                                                                      {
                                                                                        staticClass:
                                                                                          "attachment-full size-full",
                                                                                        attrs:
                                                                                          {
                                                                                            decoding:
                                                                                              "async",
                                                                                            loading:
                                                                                              "lazy",
                                                                                            width:
                                                                                              "81",
                                                                                            height:
                                                                                              "81",
                                                                                            src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/testimonial_img-11-1.jpeg",
                                                                                            alt: "",
                                                                                          },
                                                                                      }
                                                                                    ),
                                                                                  ]
                                                                                ),
                                                                                _vm._v(
                                                                                  " "
                                                                                ),
                                                                                _c(
                                                                                  "div",
                                                                                  {
                                                                                    staticClass:
                                                                                      "elementskit-profile-info",
                                                                                  },
                                                                                  [
                                                                                    _c(
                                                                                      "strong",
                                                                                      {
                                                                                        staticClass:
                                                                                          "elementskit-author-name",
                                                                                      },
                                                                                      [
                                                                                        _vm._v(
                                                                                          "John\n                                                                                            Abres"
                                                                                        ),
                                                                                      ]
                                                                                    ),
                                                                                    _vm._v(
                                                                                      " "
                                                                                    ),
                                                                                    _c(
                                                                                      "span",
                                                                                      {
                                                                                        staticClass:
                                                                                          "elementskit-author-des",
                                                                                      },
                                                                                      [
                                                                                        _vm._v(
                                                                                          "Creative\n                                                                                            Manager"
                                                                                        ),
                                                                                      ]
                                                                                    ),
                                                                                  ]
                                                                                ),
                                                                              ]
                                                                            ),
                                                                            _vm._v(
                                                                              " "
                                                                            ),
                                                                            _c(
                                                                              "div",
                                                                              {
                                                                                staticClass:
                                                                                  "elementskit-icon-content elementskit-watermark-icon",
                                                                              },
                                                                              [
                                                                                _c(
                                                                                  "i",
                                                                                  {
                                                                                    staticClass:
                                                                                      "icon icon-quote",
                                                                                    attrs:
                                                                                      {
                                                                                        "aria-hidden":
                                                                                          "true",
                                                                                      },
                                                                                  }
                                                                                ),
                                                                              ]
                                                                            ),
                                                                          ]
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "swiper-slide swiper-slide-next",
                                                                staticStyle: {
                                                                  width:
                                                                    "419px",
                                                                  "margin-right":
                                                                    "10px",
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "div",
                                                                  {
                                                                    staticClass:
                                                                      "swiper-slide-inner",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "div",
                                                                      {
                                                                        staticClass:
                                                                          "elementskit-single-testimonial-slider elementskit-testimonial-slider-block-style elementskit-testimonial-slider-block-style-two elementor-repeater-item-757950f",
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "div",
                                                                          {
                                                                            staticClass:
                                                                              "elementskit-commentor-header",
                                                                          }
                                                                        ),
                                                                        _vm._v(
                                                                          " "
                                                                        ),
                                                                        _c(
                                                                          "div",
                                                                          {
                                                                            staticClass:
                                                                              "elementskit-commentor-content",
                                                                          },
                                                                          [
                                                                            _c(
                                                                              "p",
                                                                              [
                                                                                _vm._v(
                                                                                  "View some of our work and case\n                                                                                    studies for clients. We will\n                                                                                    work to deliver that strategy by\n                                                                                    building out your existing\n                                                                                    campaigns, or establishing\n                                                                                    accounts at new networks. It’s\n                                                                                    important to us that you."
                                                                                ),
                                                                              ]
                                                                            ),
                                                                          ]
                                                                        ),
                                                                        _vm._v(
                                                                          " "
                                                                        ),
                                                                        _c(
                                                                          "div",
                                                                          {
                                                                            staticClass:
                                                                              "elementskit-commentor-bio",
                                                                          },
                                                                          [
                                                                            _c(
                                                                              "div",
                                                                              {
                                                                                staticClass:
                                                                                  "elementkit-commentor-details client_left",
                                                                              },
                                                                              [
                                                                                _c(
                                                                                  "div",
                                                                                  {
                                                                                    staticClass:
                                                                                      "elementskit-commentor-image ekit-testimonial--avatar",
                                                                                  },
                                                                                  [
                                                                                    _c(
                                                                                      "img",
                                                                                      {
                                                                                        staticClass:
                                                                                          "attachment-full size-full",
                                                                                        attrs:
                                                                                          {
                                                                                            decoding:
                                                                                              "async",
                                                                                            loading:
                                                                                              "lazy",
                                                                                            width:
                                                                                              "70",
                                                                                            height:
                                                                                              "70",
                                                                                            src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Testimonial_img-1-2.jpeg",
                                                                                            alt: "",
                                                                                          },
                                                                                      }
                                                                                    ),
                                                                                  ]
                                                                                ),
                                                                                _vm._v(
                                                                                  " "
                                                                                ),
                                                                                _c(
                                                                                  "div",
                                                                                  {
                                                                                    staticClass:
                                                                                      "elementskit-profile-info",
                                                                                  },
                                                                                  [
                                                                                    _c(
                                                                                      "strong",
                                                                                      {
                                                                                        staticClass:
                                                                                          "elementskit-author-name",
                                                                                      },
                                                                                      [
                                                                                        _vm._v(
                                                                                          "Mark\n                                                                                            Jhon"
                                                                                        ),
                                                                                      ]
                                                                                    ),
                                                                                    _vm._v(
                                                                                      " "
                                                                                    ),
                                                                                    _c(
                                                                                      "span",
                                                                                      {
                                                                                        staticClass:
                                                                                          "elementskit-author-des",
                                                                                      },
                                                                                      [
                                                                                        _vm._v(
                                                                                          "Designer"
                                                                                        ),
                                                                                      ]
                                                                                    ),
                                                                                  ]
                                                                                ),
                                                                              ]
                                                                            ),
                                                                            _vm._v(
                                                                              " "
                                                                            ),
                                                                            _c(
                                                                              "div",
                                                                              {
                                                                                staticClass:
                                                                                  "elementskit-icon-content elementskit-watermark-icon",
                                                                              },
                                                                              [
                                                                                _c(
                                                                                  "i",
                                                                                  {
                                                                                    staticClass:
                                                                                      "icon icon-quote",
                                                                                    attrs:
                                                                                      {
                                                                                        "aria-hidden":
                                                                                          "true",
                                                                                      },
                                                                                  }
                                                                                ),
                                                                              ]
                                                                            ),
                                                                          ]
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "swiper-slide",
                                                                staticStyle: {
                                                                  width:
                                                                    "419px",
                                                                  "margin-right":
                                                                    "10px",
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "div",
                                                                  {
                                                                    staticClass:
                                                                      "swiper-slide-inner",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "div",
                                                                      {
                                                                        staticClass:
                                                                          "elementskit-single-testimonial-slider elementskit-testimonial-slider-block-style elementskit-testimonial-slider-block-style-two elementor-repeater-item-29d58e5",
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "div",
                                                                          {
                                                                            staticClass:
                                                                              "elementskit-commentor-header",
                                                                          }
                                                                        ),
                                                                        _vm._v(
                                                                          " "
                                                                        ),
                                                                        _c(
                                                                          "div",
                                                                          {
                                                                            staticClass:
                                                                              "elementskit-commentor-content",
                                                                          },
                                                                          [
                                                                            _c(
                                                                              "p",
                                                                              [
                                                                                _vm._v(
                                                                                  "View some of our work and case\n                                                                                    studies for clients. We will\n                                                                                    work to deliver that strategy by\n                                                                                    building out your existing\n                                                                                    campaigns, or establishing\n                                                                                    accounts at new networks. It’s\n                                                                                    important to us that you."
                                                                                ),
                                                                              ]
                                                                            ),
                                                                          ]
                                                                        ),
                                                                        _vm._v(
                                                                          " "
                                                                        ),
                                                                        _c(
                                                                          "div",
                                                                          {
                                                                            staticClass:
                                                                              "elementskit-commentor-bio",
                                                                          },
                                                                          [
                                                                            _c(
                                                                              "div",
                                                                              {
                                                                                staticClass:
                                                                                  "elementkit-commentor-details client_left",
                                                                              },
                                                                              [
                                                                                _c(
                                                                                  "div",
                                                                                  {
                                                                                    staticClass:
                                                                                      "elementskit-commentor-image ekit-testimonial--avatar",
                                                                                  },
                                                                                  [
                                                                                    _c(
                                                                                      "img",
                                                                                      {
                                                                                        staticClass:
                                                                                          "attachment-full size-full",
                                                                                        attrs:
                                                                                          {
                                                                                            decoding:
                                                                                              "async",
                                                                                            loading:
                                                                                              "lazy",
                                                                                            width:
                                                                                              "70",
                                                                                            height:
                                                                                              "70",
                                                                                            src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/popular-post_img-2-1.jpeg",
                                                                                            alt: "",
                                                                                          },
                                                                                      }
                                                                                    ),
                                                                                  ]
                                                                                ),
                                                                                _vm._v(
                                                                                  " "
                                                                                ),
                                                                                _c(
                                                                                  "div",
                                                                                  {
                                                                                    staticClass:
                                                                                      "elementskit-profile-info",
                                                                                  },
                                                                                  [
                                                                                    _c(
                                                                                      "strong",
                                                                                      {
                                                                                        staticClass:
                                                                                          "elementskit-author-name",
                                                                                      },
                                                                                      [
                                                                                        _vm._v(
                                                                                          "Stive\n                                                                                            Smith"
                                                                                        ),
                                                                                      ]
                                                                                    ),
                                                                                    _vm._v(
                                                                                      " "
                                                                                    ),
                                                                                    _c(
                                                                                      "span",
                                                                                      {
                                                                                        staticClass:
                                                                                          "elementskit-author-des",
                                                                                      },
                                                                                      [
                                                                                        _vm._v(
                                                                                          "Manager"
                                                                                        ),
                                                                                      ]
                                                                                    ),
                                                                                  ]
                                                                                ),
                                                                              ]
                                                                            ),
                                                                            _vm._v(
                                                                              " "
                                                                            ),
                                                                            _c(
                                                                              "div",
                                                                              {
                                                                                staticClass:
                                                                                  "elementskit-icon-content elementskit-watermark-icon",
                                                                              },
                                                                              [
                                                                                _c(
                                                                                  "i",
                                                                                  {
                                                                                    staticClass:
                                                                                      "icon icon-quote",
                                                                                    attrs:
                                                                                      {
                                                                                        "aria-hidden":
                                                                                          "true",
                                                                                      },
                                                                                  }
                                                                                ),
                                                                              ]
                                                                            ),
                                                                          ]
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "swiper-navigation-button swiper-button-prev swiper-button-disabled",
                                                            attrs: {
                                                              tabindex: "-1",
                                                              role: "button",
                                                              "aria-label":
                                                                "Previous slide",
                                                              "aria-disabled":
                                                                "true",
                                                            },
                                                          },
                                                          [
                                                            _c("i", {
                                                              staticClass:
                                                                "icon icon-left-arrow",
                                                            }),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "swiper-navigation-button swiper-button-next",
                                                            attrs: {
                                                              tabindex: "0",
                                                              role: "button",
                                                              "aria-label":
                                                                "Next slide",
                                                              "aria-disabled":
                                                                "false",
                                                            },
                                                          },
                                                          [
                                                            _c("i", {
                                                              staticClass:
                                                                "icon icon-right-arrow",
                                                            }),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c("span", {
                                                          staticClass:
                                                            "swiper-notification",
                                                          attrs: {
                                                            "aria-live":
                                                              "assertive",
                                                            "aria-atomic":
                                                              "true",
                                                          },
                                                        }),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-4d64561 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
        attrs: { "data-id": "4d64561", "data-element_type": "section" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-de705c8 wdp-sticky-section-no",
                attrs: { "data-id": "de705c8", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-54536f5 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-heading animated fadeInUp",
                        attrs: {
                          "data-id": "54536f5",
                          "data-element_type": "widget",
                          "data-settings": '{"_animation":"fadeInUp"}',
                          "data-widget_type": "elementskit-heading.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("div", { staticClass: "ekit-wid-con" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "ekit-heading elementskit-section-title-wraper center ekit_heading_tablet- ekit_heading_mobile-",
                                },
                                [
                                  _c(
                                    "h2",
                                    {
                                      staticClass:
                                        "ekit-heading--title elementskit-section-title",
                                    },
                                    [
                                      _vm._v(
                                        "Team\n                                            "
                                      ),
                                      _c("span", [_vm._v("Work")]),
                                    ]
                                  ),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass: "ekit-heading__description",
                                    },
                                    [
                                      _c("p", [
                                        _vm._v(
                                          "A small river named Duden flows by their place and supplies it with\n                                                the necessary regelialia. It is a paradise"
                                        ),
                                      ]),
                                    ]
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-5e40919 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
        attrs: {
          "data-id": "5e40919",
          "data-element_type": "section",
          "data-settings": '{"background_background":"classic"}',
        },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-392814d wdp-sticky-section-no",
                attrs: { "data-id": "392814d", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-58f0c0c4 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no animated fadeIn",
                        attrs: {
                          "data-id": "58f0c0c4",
                          "data-element_type": "section",
                          "data-settings": '{"animation":"fadeIn"}',
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-47e5c7ce wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "47e5c7ce",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-6d2c45bc de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-team",
                                        attrs: {
                                          "data-id": "6d2c45bc",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-team.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "profile-image-card elementor-animation- ekit-team-img ekit-team-style-overlay text-center",
                                                  },
                                                  [
                                                    _c("img", {
                                                      staticClass:
                                                        "attachment-full size-full wp-image-1853",
                                                      attrs: {
                                                        decoding: "async",
                                                        loading: "lazy",
                                                        width: "255",
                                                        height: "255",
                                                        src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-1-2-1.jpeg",
                                                        alt: "",
                                                        srcset:
                                                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-1-2-1.jpeg" +
                                                          " 255w, " +
                                                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-1-2-1-150x150.jpeg" +
                                                          " 150w",
                                                        sizes:
                                                          "(max-width: 255px) 100vw, 255px",
                                                      },
                                                    }),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "hover-area",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "profile-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h2",
                                                              {
                                                                staticClass:
                                                                  "profile-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    John Doe "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "p",
                                                              {
                                                                staticClass:
                                                                  "profile-designation",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "WordPress Dev."
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "profile-footer",
                                                          },
                                                          [
                                                            _c(
                                                              "ul",
                                                              {
                                                                staticClass:
                                                                  "ekit-team-social-list",
                                                              },
                                                              [
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-c1bedf2",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Facebook",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-6180f02",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Twitter",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-b0fd788",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Google Plus",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-c966d3e",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Linkedin",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-5b35b066 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "5b35b066",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-5660ffe4 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-team",
                                        attrs: {
                                          "data-id": "5660ffe4",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-team.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "profile-image-card elementor-animation- ekit-team-img ekit-team-style-overlay text-center",
                                                  },
                                                  [
                                                    _c("img", {
                                                      staticClass:
                                                        "attachment-full size-full wp-image-1854",
                                                      attrs: {
                                                        decoding: "async",
                                                        loading: "lazy",
                                                        width: "255",
                                                        height: "255",
                                                        src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-2-2.jpeg",
                                                        alt: "",
                                                        srcset:
                                                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-2-2.jpeg" +
                                                          " 255w, " +
                                                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-2-2-150x150.jpeg" +
                                                          " 150w",
                                                        sizes:
                                                          "(max-width: 255px) 100vw, 255px",
                                                      },
                                                    }),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "hover-area",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "profile-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h2",
                                                              {
                                                                staticClass:
                                                                  "profile-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Elizabeth Sofia "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "p",
                                                              {
                                                                staticClass:
                                                                  "profile-designation",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "WordPress Dev."
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "profile-footer",
                                                          },
                                                          [
                                                            _c(
                                                              "ul",
                                                              {
                                                                staticClass:
                                                                  "ekit-team-social-list",
                                                              },
                                                              [
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-c1bedf2",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Facebook",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-6180f02",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Twitter",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-b0fd788",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Google Plus",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-c966d3e",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Linkedin",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-2af26b74 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "2af26b74",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-d777747 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-team",
                                        attrs: {
                                          "data-id": "d777747",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-team.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "profile-image-card elementor-animation- ekit-team-img ekit-team-style-overlay text-center",
                                                  },
                                                  [
                                                    _c("img", {
                                                      staticClass:
                                                        "attachment-full size-full wp-image-1855",
                                                      attrs: {
                                                        decoding: "async",
                                                        loading: "lazy",
                                                        width: "255",
                                                        height: "255",
                                                        src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-3-1-1.jpeg",
                                                        alt: "",
                                                        srcset:
                                                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-3-1-1.jpeg" +
                                                          " 255w, " +
                                                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-3-1-1-150x150.jpeg" +
                                                          " 150w",
                                                        sizes:
                                                          "(max-width: 255px) 100vw, 255px",
                                                      },
                                                    }),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "hover-area",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "profile-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h2",
                                                              {
                                                                staticClass:
                                                                  "profile-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Jane Doe "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "p",
                                                              {
                                                                staticClass:
                                                                  "profile-designation",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "WordPress Dev."
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "profile-footer",
                                                          },
                                                          [
                                                            _c(
                                                              "ul",
                                                              {
                                                                staticClass:
                                                                  "ekit-team-social-list",
                                                              },
                                                              [
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-c1bedf2",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Facebook",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-6180f02",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Twitter",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-b0fd788",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Google Plus",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-c966d3e",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Linkedin",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-25 elementor-inner-column elementor-element elementor-element-3e3b6980 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "3e3b6980",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-5c1861a3 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-team",
                                        attrs: {
                                          "data-id": "5c1861a3",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-team.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "profile-image-card elementor-animation- ekit-team-img ekit-team-style-overlay text-center",
                                                  },
                                                  [
                                                    _c("img", {
                                                      staticClass:
                                                        "attachment-full size-full wp-image-1856",
                                                      attrs: {
                                                        decoding: "async",
                                                        loading: "lazy",
                                                        width: "255",
                                                        height: "255",
                                                        src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-4-2.jpeg",
                                                        alt: "",
                                                        srcset:
                                                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-4-2.jpeg" +
                                                          " 255w, " +
                                                          "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Team_img-4-2-150x150.jpeg" +
                                                          " 150w",
                                                        sizes:
                                                          "(max-width: 255px) 100vw, 255px",
                                                      },
                                                    }),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "hover-area",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "profile-body",
                                                          },
                                                          [
                                                            _c(
                                                              "h2",
                                                              {
                                                                staticClass:
                                                                  "profile-title",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Sam Samia "
                                                                ),
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c(
                                                              "p",
                                                              {
                                                                staticClass:
                                                                  "profile-designation",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "WordPress Dev."
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "profile-footer",
                                                          },
                                                          [
                                                            _c(
                                                              "ul",
                                                              {
                                                                staticClass:
                                                                  "ekit-team-social-list",
                                                              },
                                                              [
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-c1bedf2",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Facebook",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-6180f02",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Twitter",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-b0fd788",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Google Plus",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "li",
                                                                  {
                                                                    staticClass:
                                                                      "elementor-repeater-item-c966d3e",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "a",
                                                                      {
                                                                        attrs: {
                                                                          href: "https://facebook.com",
                                                                          "aria-label":
                                                                            "Linkedin",
                                                                        },
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-facebook",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-1237afb5 elementor-section-boxed elementor-section-height-default wdp-sticky-section-no lazyloaded animated fadeInUp",
        attrs: {
          "data-id": "1237afb5",
          "data-element_type": "section",
          "data-settings":
            '{"background_background":"classic","animation":"fadeInUp"}',
          "data-e-bg-lazyload": "",
        },
      },
      [
        _c("div", { staticClass: "elementor-background-overlay" }),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-68a75c0d wdp-sticky-section-no",
                attrs: { "data-id": "68a75c0d", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-6dbd5f6d de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-funfact",
                        attrs: {
                          "data-id": "6dbd5f6d",
                          "data-element_type": "widget",
                          "data-widget_type": "elementskit-funfact.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("div", { staticClass: "ekit-wid-con" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "elementskit-funfact text-center divider_funfact position_top",
                                },
                                [
                                  _c("div", {
                                    staticClass:
                                      "vertical-bar border_right_side",
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass: "elementskit-funfact-inner",
                                    },
                                    [
                                      _c(
                                        "div",
                                        { staticClass: "funfact-content" },
                                        [
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "number-percentage-wraper",
                                            },
                                            [
                                              _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "number-percentage",
                                                  attrs: {
                                                    "data-value": "165",
                                                    "data-animation-duration":
                                                      "3500",
                                                    "data-style": "static",
                                                  },
                                                },
                                                [_vm._v("165")]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "span",
                                                { staticClass: "super" },
                                                [_vm._v("+")]
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "h3",
                                            { staticClass: "funfact-title" },
                                            [_vm._v("Support Given")]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-deed89d wdp-sticky-section-no",
                attrs: { "data-id": "deed89d", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-6e46e92 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-funfact",
                        attrs: {
                          "data-id": "6e46e92",
                          "data-element_type": "widget",
                          "data-widget_type": "elementskit-funfact.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("div", { staticClass: "ekit-wid-con" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "elementskit-funfact text-center divider_funfact position_top",
                                },
                                [
                                  _c("div", {
                                    staticClass:
                                      "vertical-bar border_right_side",
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass: "elementskit-funfact-inner",
                                    },
                                    [
                                      _c(
                                        "div",
                                        { staticClass: "funfact-content" },
                                        [
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "number-percentage-wraper",
                                            },
                                            [
                                              _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "number-percentage",
                                                  attrs: {
                                                    "data-value": "165",
                                                    "data-animation-duration":
                                                      "3500",
                                                    "data-style": "static",
                                                  },
                                                },
                                                [_vm._v("165")]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "span",
                                                { staticClass: "super" },
                                                [_vm._v("+")]
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "h3",
                                            { staticClass: "funfact-title" },
                                            [_vm._v("Support Given")]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-6e4fd80 wdp-sticky-section-no",
                attrs: { "data-id": "6e4fd80", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-40979e3 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-funfact",
                        attrs: {
                          "data-id": "40979e3",
                          "data-element_type": "widget",
                          "data-widget_type": "elementskit-funfact.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("div", { staticClass: "ekit-wid-con" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "elementskit-funfact text-center divider_funfact position_top",
                                },
                                [
                                  _c("div", {
                                    staticClass:
                                      "vertical-bar border_right_side",
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass: "elementskit-funfact-inner",
                                    },
                                    [
                                      _c(
                                        "div",
                                        { staticClass: "funfact-content" },
                                        [
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "number-percentage-wraper",
                                            },
                                            [
                                              _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "number-percentage",
                                                  attrs: {
                                                    "data-value": "165",
                                                    "data-animation-duration":
                                                      "3500",
                                                    "data-style": "static",
                                                  },
                                                },
                                                [_vm._v("165")]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "span",
                                                { staticClass: "super" },
                                                [_vm._v("+")]
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "h3",
                                            { staticClass: "funfact-title" },
                                            [_vm._v("Support Given")]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-25 elementor-top-column elementor-element elementor-element-6d7ad7b wdp-sticky-section-no",
                attrs: { "data-id": "6d7ad7b", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-f70525c de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-funfact",
                        attrs: {
                          "data-id": "f70525c",
                          "data-element_type": "widget",
                          "data-widget_type": "elementskit-funfact.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("div", { staticClass: "ekit-wid-con" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "elementskit-funfact text-center divider_funfact position_top",
                                },
                                [
                                  _c("div", {
                                    staticClass:
                                      "vertical-bar border_right_side",
                                  }),
                                  _vm._v(" "),
                                  _c(
                                    "div",
                                    {
                                      staticClass: "elementskit-funfact-inner",
                                    },
                                    [
                                      _c(
                                        "div",
                                        { staticClass: "funfact-content" },
                                        [
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "number-percentage-wraper",
                                            },
                                            [
                                              _c(
                                                "span",
                                                {
                                                  staticClass:
                                                    "number-percentage",
                                                  attrs: {
                                                    "data-value": "165",
                                                    "data-animation-duration":
                                                      "3500",
                                                    "data-style": "static",
                                                  },
                                                },
                                                [_vm._v("165")]
                                              ),
                                              _vm._v(" "),
                                              _c(
                                                "span",
                                                { staticClass: "super" },
                                                [_vm._v("+")]
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "h3",
                                            { staticClass: "funfact-title" },
                                            [_vm._v("Support Given")]
                                          ),
                                        ]
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-2084689b elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
        attrs: {
          "data-id": "2084689b",
          "data-element_type": "section",
          "data-settings": '{"background_background":"classic"}',
        },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-453c118b wdp-sticky-section-no",
                attrs: { "data-id": "453c118b", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-42eb2c5b elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                        attrs: {
                          "data-id": "42eb2c5b",
                          "data-element_type": "section",
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-100 elementor-inner-column elementor-element elementor-element-5ce47e4b wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "5ce47e4b",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-58f8dfb de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-heading animated fadeInUp",
                                        attrs: {
                                          "data-id": "58f8dfb",
                                          "data-element_type": "widget",
                                          "data-settings":
                                            '{"_animation":"fadeInUp"}',
                                          "data-widget_type":
                                            "elementskit-heading.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "ekit-heading elementskit-section-title-wraper center ekit_heading_tablet- ekit_heading_mobile-",
                                                  },
                                                  [
                                                    _c(
                                                      "h2",
                                                      {
                                                        staticClass:
                                                          "ekit-heading--title elementskit-section-title",
                                                      },
                                                      [
                                                        _vm._v(
                                                          "\n                                                            FAQ "
                                                        ),
                                                        _c("span", [
                                                          _vm._v("Pertanyaan"),
                                                        ]),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "ekit-heading__description",
                                                      },
                                                      [
                                                        _c("p", [
                                                          _vm._v(
                                                            "A small river named Duden flows by their place and\n                                                                supplies it with the necessary regelialia. It is a\n                                                                paradise"
                                                          ),
                                                        ]),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "section",
                      {
                        staticClass:
                          "elementor-section elementor-inner-section elementor-element elementor-element-4651948 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                        attrs: {
                          "data-id": "4651948",
                          "data-element_type": "section",
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-container elementor-column-gap-default",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-439bcc35 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "439bcc35",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-4fd9653e de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-image",
                                        attrs: {
                                          "data-id": "4fd9653e",
                                          "data-element_type": "widget",
                                          "data-widget_type": "image.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c("img", {
                                              staticClass:
                                                "attachment-full size-full wp-image-1859",
                                              attrs: {
                                                decoding: "async",
                                                loading: "lazy",
                                                width: "514",
                                                height: "548",
                                                src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/fak-mobile.png",
                                                alt: "",
                                                srcset:
                                                  "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/fak-mobile.png" +
                                                  " 514w, " +
                                                  "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/fak-mobile-281x300.png" +
                                                  " 281w",
                                                sizes:
                                                  "(max-width: 514px) 100vw, 514px",
                                              },
                                            }),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-3187b485 wdp-sticky-section-no",
                                attrs: {
                                  "data-id": "3187b485",
                                  "data-element_type": "column",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  {
                                    staticClass:
                                      "elementor-widget-wrap elementor-element-populated",
                                  },
                                  [
                                    _c(
                                      "div",
                                      {
                                        staticClass:
                                          "elementor-element elementor-element-3c9d97ae de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-accordion",
                                        attrs: {
                                          "data-id": "3c9d97ae",
                                          "data-element_type": "widget",
                                          "data-widget_type":
                                            "elementskit-accordion.default",
                                        },
                                      },
                                      [
                                        _c(
                                          "div",
                                          {
                                            staticClass:
                                              "elementor-widget-container",
                                          },
                                          [
                                            _c(
                                              "div",
                                              { staticClass: "ekit-wid-con" },
                                              [
                                                _c(
                                                  "div",
                                                  {
                                                    staticClass:
                                                      "elementskit-accordion accoedion-primary",
                                                    attrs: {
                                                      id: "accordion-64e6fb3bc21ff",
                                                    },
                                                  },
                                                  [
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-card active",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-card-header",
                                                            attrs: {
                                                              id: "primaryHeading-0-3c9d97ae",
                                                            },
                                                          },
                                                          [
                                                            _c(
                                                              "a",
                                                              {
                                                                staticClass:
                                                                  "ekit-accordion--toggler elementskit-btn-link collapsed",
                                                                attrs: {
                                                                  href: "#collapse-219959464e6fb3bc21ff",
                                                                  "data-ekit-toggle":
                                                                    "collapse",
                                                                  "data-target":
                                                                    "#Collapse-219959464e6fb3bc21ff",
                                                                  "aria-expanded":
                                                                    "true",
                                                                  "aria-controls":
                                                                    "Collapse-219959464e6fb3bc21ff",
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "span",
                                                                  {
                                                                    staticClass:
                                                                      "ekit-accordion-title",
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      " How to\n                                                                        Change my Photo from Admin Dashboard?\n                                                                    "
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "div",
                                                                  {
                                                                    staticClass:
                                                                      "ekit_accordion_icon_group",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "div",
                                                                      {
                                                                        staticClass:
                                                                          "ekit_accordion_normal_icon",
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-plus icon-open icon-right",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                    _vm._v(" "),
                                                                    _c(
                                                                      "div",
                                                                      {
                                                                        staticClass:
                                                                          "ekit_accordion_active_icon",
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-minus icon-closed icon-right",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "show collapse",
                                                            attrs: {
                                                              id: "Collapse-219959464e6fb3bc21ff",
                                                              "aria-labelledby":
                                                                "primaryHeading-0-3c9d97ae",
                                                              "data-parent":
                                                                "#accordion-64e6fb3bc21ff",
                                                            },
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-card-body ekit-accordion--content",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Far far away, behind the word mountains, far\n                                                                    from the countries Vokalia and Consonantia,\n                                                                    there live the blind texts. Separated they live\n                                                                    in Bookmarksgrove right at the coast "
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-card",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-card-header",
                                                            attrs: {
                                                              id: "primaryHeading-1-3c9d97ae",
                                                            },
                                                          },
                                                          [
                                                            _c(
                                                              "a",
                                                              {
                                                                staticClass:
                                                                  "ekit-accordion--toggler elementskit-btn-link collapsed",
                                                                attrs: {
                                                                  href: "#collapse-ae2191d64e6fb3bc21ff",
                                                                  "data-ekit-toggle":
                                                                    "collapse",
                                                                  "data-target":
                                                                    "#Collapse-ae2191d64e6fb3bc21ff",
                                                                  "aria-expanded":
                                                                    "false",
                                                                  "aria-controls":
                                                                    "Collapse-ae2191d64e6fb3bc21ff",
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "span",
                                                                  {
                                                                    staticClass:
                                                                      "ekit-accordion-title",
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      " How to\n                                                                        Change my Password easily?"
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "div",
                                                                  {
                                                                    staticClass:
                                                                      "ekit_accordion_icon_group",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "div",
                                                                      {
                                                                        staticClass:
                                                                          "ekit_accordion_normal_icon",
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-plus icon-open icon-right",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                    _vm._v(" "),
                                                                    _c(
                                                                      "div",
                                                                      {
                                                                        staticClass:
                                                                          "ekit_accordion_active_icon",
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-minus icon-closed icon-right",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "collapse",
                                                            attrs: {
                                                              id: "Collapse-ae2191d64e6fb3bc21ff",
                                                              "aria-labelledby":
                                                                "primaryHeading-1-3c9d97ae",
                                                              "data-parent":
                                                                "#accordion-64e6fb3bc21ff",
                                                            },
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-card-body ekit-accordion--content",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Far far away, behind the word mountains, far\n                                                                    from the countries Vokalia and Consonantia,\n                                                                    there live the blind texts. Separated they live\n                                                                    in Bookmarksgrove right at the coast "
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                    _vm._v(" "),
                                                    _c(
                                                      "div",
                                                      {
                                                        staticClass:
                                                          "elementskit-card",
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "elementskit-card-header",
                                                            attrs: {
                                                              id: "primaryHeading-2-3c9d97ae",
                                                            },
                                                          },
                                                          [
                                                            _c(
                                                              "a",
                                                              {
                                                                staticClass:
                                                                  "ekit-accordion--toggler elementskit-btn-link collapsed",
                                                                attrs: {
                                                                  href: "#collapse-18730b264e6fb3bc21ff",
                                                                  "data-ekit-toggle":
                                                                    "collapse",
                                                                  "data-target":
                                                                    "#Collapse-18730b264e6fb3bc21ff",
                                                                  "aria-expanded":
                                                                    "false",
                                                                  "aria-controls":
                                                                    "Collapse-18730b264e6fb3bc21ff",
                                                                },
                                                              },
                                                              [
                                                                _c(
                                                                  "span",
                                                                  {
                                                                    staticClass:
                                                                      "ekit-accordion-title",
                                                                  },
                                                                  [
                                                                    _vm._v(
                                                                      " How to\n                                                                        Change my Subscription Plan using\n                                                                        PayPal"
                                                                    ),
                                                                  ]
                                                                ),
                                                                _vm._v(" "),
                                                                _c(
                                                                  "div",
                                                                  {
                                                                    staticClass:
                                                                      "ekit_accordion_icon_group",
                                                                  },
                                                                  [
                                                                    _c(
                                                                      "div",
                                                                      {
                                                                        staticClass:
                                                                          "ekit_accordion_normal_icon",
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-plus icon-open icon-right",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                    _vm._v(" "),
                                                                    _c(
                                                                      "div",
                                                                      {
                                                                        staticClass:
                                                                          "ekit_accordion_active_icon",
                                                                      },
                                                                      [
                                                                        _c(
                                                                          "i",
                                                                          {
                                                                            staticClass:
                                                                              "icon icon-minus icon-closed icon-right",
                                                                            attrs:
                                                                              {
                                                                                "aria-hidden":
                                                                                  "true",
                                                                              },
                                                                          }
                                                                        ),
                                                                      ]
                                                                    ),
                                                                  ]
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                        _vm._v(" "),
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "collapse",
                                                            attrs: {
                                                              id: "Collapse-18730b264e6fb3bc21ff",
                                                              "aria-labelledby":
                                                                "primaryHeading-2-3c9d97ae",
                                                              "data-parent":
                                                                "#accordion-64e6fb3bc21ff",
                                                            },
                                                          },
                                                          [
                                                            _c(
                                                              "div",
                                                              {
                                                                staticClass:
                                                                  "elementskit-card-body ekit-accordion--content",
                                                              },
                                                              [
                                                                _vm._v(
                                                                  "\n                                                                    Far far away, behind the word mountains, far\n                                                                    from the countries Vokalia and Consonantia,\n                                                                    there live the blind texts. Separated they live\n                                                                    in Bookmarksgrove right at the coast "
                                                                ),
                                                              ]
                                                            ),
                                                          ]
                                                        ),
                                                      ]
                                                    ),
                                                  ]
                                                ),
                                              ]
                                            ),
                                          ]
                                        ),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-6312d9b4 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no animated fadeIn",
        attrs: {
          "data-id": "6312d9b4",
          "data-element_type": "section",
          "data-settings": '{"animation":"fadeIn"}',
        },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-43f66143 wdp-sticky-section-no",
                attrs: { "data-id": "43f66143", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-54b1cc20 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-client-logo",
                        attrs: {
                          "data-id": "54b1cc20",
                          "data-element_type": "widget",
                          "data-widget_type": "elementskit-client-logo.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("div", { staticClass: "ekit-wid-con" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "elementskit-clients-slider simple_logo_image",
                                  attrs: {
                                    "data-config":
                                      '{"rtl":false,"arrows":false,"dots":false,"autoplay":false,"speed":1000,"slidesPerView":4,"slidesPerGroup":1,"pauseOnHover":false,"loop":false,"breakpoints":{"320":{"slidesPerView":1,"slidesPerGroup":1,"spaceBetween":10},"768":{"slidesPerView":"3","slidesPerGroup":1,"spaceBetween":10},"1024":{"slidesPerView":4,"slidesPerGroup":1,"spaceBetween":15}}}',
                                    "data-direction": "",
                                  },
                                },
                                [
                                  _c(
                                    "div",
                                    {
                                      staticClass:
                                        "ekit-main-swiper swiper swiper-container-initialized swiper-container-horizontal",
                                    },
                                    [
                                      _c(
                                        "div",
                                        {
                                          staticClass: "swiper-wrapper",
                                          staticStyle: {
                                            transform:
                                              "translate3d(0px, 0px, 0px)",
                                          },
                                        },
                                        [
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "elementskit-client-slider-item swiper-slide log-separator swiper-slide-active",
                                              staticStyle: {
                                                width: "726px",
                                                "margin-right": "10px",
                                              },
                                            },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "swiper-slide-inner",
                                                },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "single-client image-switcher",
                                                      attrs: {
                                                        title: "San marinas",
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "a",
                                                        {
                                                          attrs: {
                                                            href: "https://www.google.com/",
                                                          },
                                                        },
                                                        [
                                                          _c(
                                                            "span",
                                                            {
                                                              staticClass:
                                                                "content-image",
                                                            },
                                                            [
                                                              _c("img", {
                                                                attrs: {
                                                                  decoding:
                                                                    "async",
                                                                  loading:
                                                                    "lazy",
                                                                  width: "142",
                                                                  height: "80",
                                                                  src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Partner_img-1-3.png",
                                                                  alt: "",
                                                                },
                                                              }),
                                                            ]
                                                          ),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "elementskit-client-slider-item swiper-slide log-separator swiper-slide-next",
                                              staticStyle: {
                                                width: "726px",
                                                "margin-right": "10px",
                                              },
                                            },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "swiper-slide-inner",
                                                },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "single-client image-switcher",
                                                      attrs: {
                                                        title: "Heritage",
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "a",
                                                        {
                                                          attrs: { href: "#" },
                                                        },
                                                        [
                                                          _c(
                                                            "span",
                                                            {
                                                              staticClass:
                                                                "content-image",
                                                            },
                                                            [
                                                              _c("img", {
                                                                attrs: {
                                                                  decoding:
                                                                    "async",
                                                                  loading:
                                                                    "lazy",
                                                                  width: "87",
                                                                  height: "80",
                                                                  src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Partner_img-2-3.png",
                                                                  alt: "",
                                                                },
                                                              }),
                                                            ]
                                                          ),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "elementskit-client-slider-item swiper-slide log-separator",
                                              staticStyle: {
                                                width: "726px",
                                                "margin-right": "10px",
                                              },
                                            },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "swiper-slide-inner",
                                                },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "single-client image-switcher",
                                                      attrs: {
                                                        title:
                                                          "Tenesse Hipster",
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "a",
                                                        {
                                                          attrs: { href: "#" },
                                                        },
                                                        [
                                                          _c(
                                                            "span",
                                                            {
                                                              staticClass:
                                                                "content-image",
                                                            },
                                                            [
                                                              _c("img", {
                                                                attrs: {
                                                                  decoding:
                                                                    "async",
                                                                  loading:
                                                                    "lazy",
                                                                  width: "155",
                                                                  height: "80",
                                                                  src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Partner_img-3-3.png",
                                                                  alt: "",
                                                                },
                                                              }),
                                                            ]
                                                          ),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "elementskit-client-slider-item swiper-slide log-separator",
                                              staticStyle: {
                                                width: "726px",
                                                "margin-right": "10px",
                                              },
                                            },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "swiper-slide-inner",
                                                },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "single-client image-switcher",
                                                      attrs: {
                                                        title: "Sophie",
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "a",
                                                        {
                                                          attrs: { href: "#" },
                                                        },
                                                        [
                                                          _c(
                                                            "span",
                                                            {
                                                              staticClass:
                                                                "content-image",
                                                            },
                                                            [
                                                              _c("img", {
                                                                attrs: {
                                                                  decoding:
                                                                    "async",
                                                                  loading:
                                                                    "lazy",
                                                                  width: "111",
                                                                  height: "80",
                                                                  src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Partner_img-4-3-1.png",
                                                                  alt: "",
                                                                },
                                                              }),
                                                            ]
                                                          ),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "elementskit-client-slider-item swiper-slide log-separator",
                                              staticStyle: {
                                                width: "726px",
                                                "margin-right": "10px",
                                              },
                                            },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "swiper-slide-inner",
                                                },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "single-client image-switcher",
                                                      attrs: {
                                                        title: "Lumberjacks",
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "a",
                                                        {
                                                          attrs: { href: "#" },
                                                        },
                                                        [
                                                          _c(
                                                            "span",
                                                            {
                                                              staticClass:
                                                                "content-image",
                                                            },
                                                            [
                                                              _c("img", {
                                                                attrs: {
                                                                  decoding:
                                                                    "async",
                                                                  loading:
                                                                    "lazy",
                                                                  width: "126",
                                                                  height: "80",
                                                                  src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Partner_img-5-3.png",
                                                                  alt: "",
                                                                },
                                                              }),
                                                            ]
                                                          ),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "elementskit-client-slider-item swiper-slide log-separator",
                                              staticStyle: {
                                                width: "726px",
                                                "margin-right": "10px",
                                              },
                                            },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "swiper-slide-inner",
                                                },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "single-client image-switcher",
                                                      attrs: {
                                                        title:
                                                          "Tenesse Hipster",
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "a",
                                                        {
                                                          attrs: { href: "#" },
                                                        },
                                                        [
                                                          _c(
                                                            "span",
                                                            {
                                                              staticClass:
                                                                "content-image",
                                                            },
                                                            [
                                                              _c("img", {
                                                                attrs: {
                                                                  decoding:
                                                                    "async",
                                                                  loading:
                                                                    "lazy",
                                                                  width: "155",
                                                                  height: "80",
                                                                  src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Partner_img-3-3.png",
                                                                  alt: "",
                                                                },
                                                              }),
                                                            ]
                                                          ),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                            ]
                                          ),
                                          _vm._v(" "),
                                          _c(
                                            "div",
                                            {
                                              staticClass:
                                                "elementskit-client-slider-item swiper-slide log-separator",
                                              staticStyle: {
                                                width: "726px",
                                                "margin-right": "10px",
                                              },
                                            },
                                            [
                                              _c(
                                                "div",
                                                {
                                                  staticClass:
                                                    "swiper-slide-inner",
                                                },
                                                [
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass:
                                                        "single-client image-switcher",
                                                      attrs: {
                                                        title: "Sophie",
                                                      },
                                                    },
                                                    [
                                                      _c(
                                                        "a",
                                                        {
                                                          attrs: { href: "#" },
                                                        },
                                                        [
                                                          _c(
                                                            "span",
                                                            {
                                                              staticClass:
                                                                "content-image",
                                                            },
                                                            [
                                                              _c("img", {
                                                                attrs: {
                                                                  decoding:
                                                                    "async",
                                                                  loading:
                                                                    "lazy",
                                                                  width: "111",
                                                                  height: "80",
                                                                  src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/Partner_img-4-3-1.png",
                                                                  alt: "",
                                                                },
                                                              }),
                                                            ]
                                                          ),
                                                        ]
                                                      ),
                                                    ]
                                                  ),
                                                ]
                                              ),
                                            ]
                                          ),
                                        ]
                                      ),
                                      _vm._v(" "),
                                      _c("span", {
                                        staticClass: "swiper-notification",
                                        attrs: {
                                          "aria-live": "assertive",
                                          "aria-atomic": "true",
                                        },
                                      }),
                                    ]
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-728fea2 wdp-sticky-section-no",
        attrs: { "data-id": "728fea2", "data-element_type": "column" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-widget-wrap elementor-element-populated" },
          [
            _c(
              "section",
              {
                staticClass:
                  "elementor-section elementor-inner-section elementor-element elementor-element-0e1e5f1 elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
                attrs: { "data-id": "0e1e5f1", "data-element_type": "section" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-container elementor-column-gap-default",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-4909106 wdp-sticky-section-no",
                        attrs: {
                          "data-id": "4909106",
                          "data-element_type": "column",
                        },
                      },
                      [
                        _c(
                          "div",
                          {
                            staticClass:
                              "elementor-widget-wrap elementor-element-populated",
                          },
                          [
                            _c(
                              "div",
                              {
                                staticClass:
                                  "elementor-element elementor-element-909211a de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-image",
                                attrs: {
                                  "data-id": "909211a",
                                  "data-element_type": "widget",
                                  "data-widget_type": "image.default",
                                },
                              },
                              [
                                _c(
                                  "div",
                                  { staticClass: "elementor-widget-container" },
                                  [
                                    _c(
                                      "a",
                                      {
                                        attrs: {
                                          href: "http://anaslawoffice.com",
                                        },
                                      },
                                      [
                                        _c("img", {
                                          staticClass:
                                            "attachment-full size-full wp-image-2353",
                                          attrs: {
                                            decoding: "async",
                                            loading: "lazy",
                                            width: "154",
                                            height: "80",
                                            src: "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/client_3_white.png",
                                            alt: "",
                                            srcset:
                                              "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/client_3_white.png" +
                                              " 154w, " +
                                              "https://anaslawoffice.dakreativ.com/wp-content/uploads/2023/07/client_3_white-18x9.png" +
                                              " 18w",
                                            sizes:
                                              "(max-width: 154px) 100vw, 154px",
                                          },
                                        }),
                                      ]
                                    ),
                                  ]
                                ),
                              ]
                            ),
                          ]
                        ),
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-column elementor-col-50 elementor-inner-column elementor-element elementor-element-c92a822 wdp-sticky-section-no",
                        attrs: {
                          "data-id": "c92a822",
                          "data-element_type": "column",
                        },
                      },
                      [_c("div", { staticClass: "elementor-widget-wrap" })]
                    ),
                  ]
                ),
              ]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-92f5727 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-text-editor",
                attrs: {
                  "data-id": "92f5727",
                  "data-element_type": "widget",
                  "data-widget_type": "text-editor.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c("p", [
                    _vm._v(
                      "kadhfkahdja lahfkjahkahflajal lahflahfldafallkfha lahflkahfakldalalkfa\n                                    klafhkalhdald lafhalfa lahflafhakf lahfalkf aflahflaf al"
                    ),
                  ]),
                ]),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-element elementor-element-bea2256 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-heading",
        attrs: {
          "data-id": "bea2256",
          "data-element_type": "widget",
          "data-widget_type": "heading.default",
        },
      },
      [
        _c("div", { staticClass: "elementor-widget-container" }, [
          _c(
            "h2",
            { staticClass: "elementor-heading-title elementor-size-default" },
            [_vm._v("Hubungi Kami")]
          ),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("span", { staticClass: "elementor-icon-list-text" }, [
      _c("span", { staticClass: "ekit_page_list_title_title" }, [
        _vm._v("+6283821877654"),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("span", { staticClass: "elementor-icon-list-text" }, [
      _c("span", { staticClass: "ekit_page_list_title_title" }, [
        _vm._v("lawofficeanas@gmail.com"),
      ]),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c("div", { staticClass: "elementor-icon-list-item" }, [
      _c(
        "a",
        {
          staticClass: "elementor-repeater-item-eb4e2e8 ekit_badge_left",
          attrs: {
            href: "https://www.google.com/maps/place/Kantor+Hukum+ANAS+%26+PARTNERS/@-6.4677997,107.9375482,17z/data=!3m1!4b1!4m6!3m5!1s0x2e69375b581e4c0b:0x891b7d6b2c9fa2a4!8m2!3d-6.4677997!4d107.9375482!16s%2Fg%2F11rft1rmy8?entry=ttu",
            target: "_blank",
            rel: "nofollow",
          },
        },
        [
          _c("div", { staticClass: "ekit_page_list_content" }, [
            _c("span", { staticClass: "elementor-icon-list-icon" }, [
              _c("i", {
                staticClass: "icon icon-map-marker1",
                attrs: { "aria-hidden": "true" },
              }),
            ]),
            _vm._v(" "),
            _c("span", { staticClass: "elementor-icon-list-text" }, [
              _c("span", { staticClass: "ekit_page_list_title_title" }, [
                _vm._v(
                  "Jl. Basuki Rahmat,\n                                                            Sukajati, Kec. Haurgeulis, Kabupaten Indramayu, Jawa\n                                                            Barat 45264"
                ),
              ]),
            ]),
          ]),
        ]
      ),
    ])
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass:
          "elementor-column elementor-col-33 elementor-top-column elementor-element elementor-element-38e1840 wdp-sticky-section-no",
        attrs: { "data-id": "38e1840", "data-element_type": "column" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-widget-wrap elementor-element-populated" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-4bb3ede de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-heading",
                attrs: {
                  "data-id": "4bb3ede",
                  "data-element_type": "widget",
                  "data-widget_type": "heading.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c(
                    "h2",
                    {
                      staticClass:
                        "elementor-heading-title elementor-size-default",
                    },
                    [_vm._v("Sosial Media")]
                  ),
                ]),
              ]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass:
                  "elementor-element elementor-element-7b36b21 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-social-media",
                attrs: {
                  "data-id": "7b36b21",
                  "data-element_type": "widget",
                  "data-widget_type": "elementskit-social-media.default",
                },
              },
              [
                _c("div", { staticClass: "elementor-widget-container" }, [
                  _c("div", { staticClass: "ekit-wid-con" }, [
                    _c("ul", { staticClass: "ekit_social_media" }, [
                      _c(
                        "li",
                        { staticClass: "elementor-repeater-item-da8f4de" },
                        [
                          _c(
                            "a",
                            {
                              staticClass: "facebook",
                              attrs: {
                                href: "http://www.facebook.com/anaslawoffice",
                                "aria-label": "Facebook",
                              },
                            },
                            [
                              _c("i", {
                                staticClass: "icon icon-facebook",
                                attrs: { "aria-hidden": "true" },
                              }),
                            ]
                          ),
                        ]
                      ),
                      _vm._v(" "),
                      _c(
                        "li",
                        { staticClass: "elementor-repeater-item-3674b22" },
                        [
                          _c(
                            "a",
                            {
                              staticClass: "1",
                              attrs: {
                                href: "http://www.instagram.com/anaslawoffice",
                                "aria-label": "linkedin",
                              },
                            },
                            [
                              _c("i", {
                                staticClass: "icon icon-instagram-1",
                                attrs: { "aria-hidden": "true" },
                              }),
                            ]
                          ),
                        ]
                      ),
                    ]),
                  ]),
                ]),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "section",
      {
        staticClass:
          "elementor-section elementor-top-section elementor-element elementor-element-9abb8ce elementor-section-boxed elementor-section-height-default elementor-section-height-default wdp-sticky-section-no",
        attrs: { "data-id": "9abb8ce", "data-element_type": "section" },
      },
      [
        _c(
          "div",
          { staticClass: "elementor-container elementor-column-gap-default" },
          [
            _c(
              "div",
              {
                staticClass:
                  "elementor-column elementor-col-100 elementor-top-column elementor-element elementor-element-68c20e2 wdp-sticky-section-no",
                attrs: { "data-id": "68c20e2", "data-element_type": "column" },
              },
              [
                _c(
                  "div",
                  {
                    staticClass:
                      "elementor-widget-wrap elementor-element-populated",
                  },
                  [
                    _c(
                      "div",
                      {
                        staticClass:
                          "elementor-element elementor-element-5f380f4 de_scroll_animation_no wdp-sticky-section-no elementor-widget elementor-widget-elementskit-heading",
                        attrs: {
                          "data-id": "5f380f4",
                          "data-element_type": "widget",
                          "data-widget_type": "elementskit-heading.default",
                        },
                      },
                      [
                        _c(
                          "div",
                          { staticClass: "elementor-widget-container" },
                          [
                            _c("div", { staticClass: "ekit-wid-con" }, [
                              _c(
                                "div",
                                {
                                  staticClass:
                                    "ekit-heading elementskit-section-title-wraper text_center ekit_heading_tablet- ekit_heading_mobile-text_center",
                                },
                                [
                                  _c(
                                    "p",
                                    {
                                      staticClass:
                                        "ekit-heading--title elementskit-section-title",
                                    },
                                    [
                                      _vm._v(
                                        "©2023 Powered\n                                            Agency Usep "
                                      ),
                                    ]
                                  ),
                                ]
                              ),
                            ]),
                          ]
                        ),
                      ]
                    ),
                  ]
                ),
              ]
            ),
          ]
        ),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      { staticClass: "woocommerce", attrs: { id: "htwlquick-viewmodal" } },
      [
        _c("div", { staticClass: "htwl-modal-dialog product" }, [
          _c("div", { staticClass: "htwl-modal-content" }, [
            _c(
              "button",
              { staticClass: "htcloseqv", attrs: { type: "button" } },
              [_c("span", { staticClass: "sli sli-close" })]
            ),
            _vm._v(" "),
            _c("div", { staticClass: "htwl-modal-body" }),
          ]),
        ]),
      ]
    )
  },
  function () {
    var _vm = this
    var _h = _vm.$createElement
    var _c = _vm._self._c || _h
    return _c(
      "div",
      {
        staticClass: "pswp",
        attrs: { tabindex: "-1", role: "dialog", "aria-hidden": "true" },
      },
      [
        _c("div", { staticClass: "pswp__bg" }),
        _vm._v(" "),
        _c("div", { staticClass: "pswp__scroll-wrap" }, [
          _c("div", { staticClass: "pswp__container" }, [
            _c("div", { staticClass: "pswp__item" }),
            _vm._v(" "),
            _c("div", { staticClass: "pswp__item" }),
            _vm._v(" "),
            _c("div", { staticClass: "pswp__item" }),
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "pswp__ui pswp__ui--hidden" }, [
            _c("div", { staticClass: "pswp__top-bar" }, [
              _c("div", { staticClass: "pswp__counter" }),
              _vm._v(" "),
              _c("button", {
                staticClass: "pswp__button pswp__button--close",
                attrs: { "aria-label": "Close (Esc)" },
              }),
              _vm._v(" "),
              _c("button", {
                staticClass: "pswp__button pswp__button--share",
                attrs: { "aria-label": "Share" },
              }),
              _vm._v(" "),
              _c("button", {
                staticClass: "pswp__button pswp__button--fs",
                attrs: { "aria-label": "Toggle fullscreen" },
              }),
              _vm._v(" "),
              _c("button", {
                staticClass: "pswp__button pswp__button--zoom",
                attrs: { "aria-label": "Zoom in/out" },
              }),
              _vm._v(" "),
              _c("div", { staticClass: "pswp__preloader" }, [
                _c("div", { staticClass: "pswp__preloader__icn" }, [
                  _c("div", { staticClass: "pswp__preloader__cut" }, [
                    _c("div", { staticClass: "pswp__preloader__donut" }),
                  ]),
                ]),
              ]),
            ]),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass:
                  "pswp__share-modal pswp__share-modal--hidden pswp__single-tap",
              },
              [_c("div", { staticClass: "pswp__share-tooltip" })]
            ),
            _vm._v(" "),
            _c("button", {
              staticClass: "pswp__button pswp__button--arrow--left",
              attrs: { "aria-label": "Previous (arrow left)" },
            }),
            _vm._v(" "),
            _c("button", {
              staticClass: "pswp__button pswp__button--arrow--right",
              attrs: { "aria-label": "Next (arrow right)" },
            }),
            _vm._v(" "),
            _c("div", { staticClass: "pswp__caption" }, [
              _c("div", { staticClass: "pswp__caption__center" }),
            ]),
          ]),
        ]),
      ]
    )
  },
]
render._withStripped = true



/***/ })

}]);